
import { Web3Storage } from 'web3.storage';

// Encryption utilities
const generateEncryptionKey = (): string => {
  const array = new Uint8Array(32);
  window.crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
};

// AES encryption using the Web Crypto API
export const encryptData = async (data: ArrayBuffer, encryptionKey: string): Promise<ArrayBuffer> => {
  try {
    const key = await window.crypto.subtle.importKey(
      'raw',
      hexStringToArrayBuffer(encryptionKey),
      { name: 'AES-GCM' },
      false,
      ['encrypt']
    );
    
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv
      },
      key,
      data
    );
    
    // Combine IV and encrypted data
    const combined = new Uint8Array(iv.length + new Uint8Array(encrypted).length);
    combined.set(iv, 0);
    combined.set(new Uint8Array(encrypted), iv.length);
    
    return combined.buffer;
  } catch (error) {
    console.error('Encryption failed:', error);
    throw new Error('Failed to encrypt data');
  }
};

// AES decryption using the Web Crypto API
export const decryptData = async (encryptedData: ArrayBuffer, encryptionKey: string): Promise<ArrayBuffer> => {
  try {
    const key = await window.crypto.subtle.importKey(
      'raw',
      hexStringToArrayBuffer(encryptionKey),
      { name: 'AES-GCM' },
      false,
      ['decrypt']
    );
    
    // Extract IV and encrypted data
    const iv = new Uint8Array(encryptedData.slice(0, 12));
    const data = new Uint8Array(encryptedData.slice(12));
    
    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv
      },
      key,
      data
    );
    
    return decrypted;
  } catch (error) {
    console.error('Decryption failed:', error);
    throw new Error('Failed to decrypt data');
  }
};

// Helper function to convert hex string to ArrayBuffer
const hexStringToArrayBuffer = (hexString: string): ArrayBuffer => {
  const bytes = new Uint8Array(hexString.length / 2);
  for (let i = 0; i < hexString.length; i += 2) {
    bytes[i / 2] = parseInt(hexString.substring(i, i + 2), 16);
  }
  return bytes.buffer;
};

// Helper function to convert ArrayBuffer to Hex string
export const arrayBufferToHexString = (buffer: ArrayBuffer): string => {
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
};

// IPFS storage class
export class IPFSStorage {
  private client: Web3Storage | null = null;
  
  constructor(token?: string) {
    if (token) {
      this.client = new Web3Storage({ token });
    }
  }
  
  // Initialize with token
  initialize(token: string) {
    this.client = new Web3Storage({ token });
  }
  
  // Upload file to IPFS with encryption
  async uploadEncrypted(file: File): Promise<{ cid: string, encryptionKey: string }> {
    if (!this.client) {
      throw new Error('IPFS client not initialized. Please provide a token.');
    }
    
    try {
      // Generate encryption key
      const encryptionKey = generateEncryptionKey();
      
      // Read file as ArrayBuffer
      const fileBuffer = await file.arrayBuffer();
      
      // Encrypt file data
      const encryptedBuffer = await encryptData(fileBuffer, encryptionKey);
      
      // Create a new File object with encrypted data
      const encryptedFile = new File([encryptedBuffer], file.name, { type: file.type });
      
      // Upload encrypted file to IPFS
      const cid = await this.client.put([encryptedFile]);
      
      return {
        cid,
        encryptionKey
      };
    } catch (error) {
      console.error('Failed to upload file:', error);
      throw new Error('Failed to upload file to IPFS');
    }
  }
  
  // Retrieve and decrypt file from IPFS
  async retrieveAndDecrypt(cid: string, encryptionKey: string, filename: string): Promise<File> {
    if (!this.client) {
      throw new Error('IPFS client not initialized. Please provide a token.');
    }
    
    try {
      // Retrieve encrypted file from IPFS
      const res = await fetch(`https://${cid}.ipfs.w3s.link/${filename}`);
      const encryptedBuffer = await res.arrayBuffer();
      
      // Decrypt the file
      const decryptedBuffer = await decryptData(encryptedBuffer, encryptionKey);
      
      // Create a new File object with decrypted data
      return new File([decryptedBuffer], filename);
    } catch (error) {
      console.error('Failed to retrieve and decrypt file:', error);
      throw new Error('Failed to retrieve file from IPFS');
    }
  }
  
  // Check if a CID exists on IPFS
  async exists(cid: string): Promise<boolean> {
    try {
      const res = await fetch(`https://${cid}.ipfs.w3s.link/`);
      return res.ok;
    } catch (error) {
      return false;
    }
  }
}

export default new IPFSStorage();
