
import { useState } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useUserStore } from "@/store/userStore";
import { useWeb3 } from "@/context/Web3Context";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const [role, setRole] = useState<"student" | "institute">("student");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const { setProfile, setAuthenticated } = useUserStore();
  const { account } = useWeb3();
  const navigate = useNavigate();

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!account) return;

    // In a real application, this would include blockchain interactions
    setProfile({
      address: account,
      role,
      name,
      email,
      isVerified: false,
    });
    
    setAuthenticated(true);
    
    // Redirect to the appropriate dashboard
    navigate(role === "student" ? "/dashboard" : "/institute/dashboard");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto pt-28 pb-16 px-4">
        <div className="max-w-md mx-auto">
          <Card className="p-6">
            <h1 className="text-2xl font-bold mb-6">Create an Account</h1>
            
            <form onSubmit={handleRegister}>
              <div className="mb-6">
                <h2 className="text-lg font-medium mb-3">Choose account type</h2>
                <RadioGroup
                  value={role}
                  onValueChange={(value) => setRole(value as "student" | "institute")}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="student" id="student" />
                    <Label htmlFor="student">Student</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="institute" id="institute" />
                    <Label htmlFor="institute">Institute</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    {role === "student" ? "Full Name" : "Institute Name"}
                  </Label>
                  <Input
                    id="name"
                    placeholder={role === "student" ? "enter your name" : "University of Technology"}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                
                <div className="pt-2">
                  <Button type="submit" className="w-full">
                    Register
                  </Button>
                </div>
              </div>
            </form>
            
            <p className="text-center text-sm text-muted-foreground mt-6">
              By registering, you agree to the processing of your personal information
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Register;
