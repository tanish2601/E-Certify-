
import { Navbar } from "@/components/layout/Navbar";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto pt-28 pb-16 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About E-Certify</h1>
            <p className="text-xl text-muted-foreground">
              A revolutionary platform for secure, verifiable digital certificates
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="prose prose-lg dark:prose-invert max-w-none"
          >
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p>
              E-Certify was founded with a simple but powerful mission: to revolutionize 
              how academic and professional certificates are issued, verified, and shared. 
              In today's digital world, credentials should be as portable, secure, and 
              verifiable as digital currency.
            </p>

            <h2 className="text-2xl font-bold mt-8 mb-4">The Problem We're Solving</h2>
            <p>
              Traditional paper certificates and even digital PDFs face numerous problems:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Easy to forge or tamper with</li>
              <li>Difficult to verify authenticity</li>
              <li>Cumbersome sharing and verification processes</li>
              <li>Risk of loss or damage</li>
              <li>No single source of truth for verification</li>
            </ul>

            <h2 className="text-2xl font-bold mt-8 mb-4">Our Blockchain Solution</h2>
            <p>
              By leveraging blockchain technology and IPFS (InterPlanetary File System), 
              E-Certify creates tamper-proof, permanently verifiable credentials:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Certificates are cryptographically signed by both issuer and recipient</li>
              <li>All certificate data is stored on immutable blockchain ledgers</li>
              <li>Certificate files are encrypted and stored on decentralized IPFS</li>
              <li>Instant verification without intermediaries</li>
              <li>Time-limited sharing with cryptographic access controls</li>
            </ul>

            <h2 className="text-2xl font-bold mt-8 mb-4">Our Team</h2>
            <p>
              Our team consists of blockchain specialists, cryptographers, and education 
              technology experts committed to building the future of digital credentials.
            </p>

            <div className="mt-12 text-center">
              <Button asChild size="lg" className="mr-4">
                <Link to="/features">Explore Features</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default About;
