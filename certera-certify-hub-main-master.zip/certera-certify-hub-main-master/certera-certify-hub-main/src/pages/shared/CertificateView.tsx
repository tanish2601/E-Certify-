
import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/sonner";
import { Award, Check, Clock, Download, ExternalLink, Lock, Shield, Smile, User } from "lucide-react";

const CertificateView = () => {
  const { id } = useParams<{ id: string }>();
  const [isLoading, setIsLoading] = useState(true);
  const [isVerified, setIsVerified] = useState(false);
  const [showVerificationDetails, setShowVerificationDetails] = useState(false);
  const [certificateData, setCertificateData] = useState<{
    id: string;
    title: string;
    recipient: string;
    issuer: string;
    issueDate: string;
    expiryDate: string | null;
    description: string;
    blockchainHash: string;
    ipfsHash: string;
    imageUrl: string;
    accessExpiry: string;
  } | null>(null);

  useEffect(() => {
    // Simulate loading certificate data
    const fetchCertificate = async () => {
      setIsLoading(true);
      try {
        // In a real app, we would fetch the certificate data from IPFS using the ID
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Dummy data
        setCertificateData({
          id: id || "CERT-123456",
          title: "Bachelor of Computer Science",
          recipient: "Sarah Johnson",
          issuer: "Tech University",
          issueDate: "2023-05-15",
          expiryDate: null,
          description: "This certificate is awarded for successfully completing the four-year program in Computer Science with specialization in Artificial Intelligence and Machine Learning.",
          blockchainHash: "0xabc123def456789...",
          ipfsHash: "QmXyZ123AbC...",
          imageUrl: "https://images.unsplash.com/photo-1606326608606-aa0b62935f2b",
          accessExpiry: "2025-05-01"
        });
        
        // Simulate blockchain verification
        await new Promise(resolve => setTimeout(resolve, 800));
        setIsVerified(true);
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching certificate:", error);
        setIsLoading(false);
        toast.error("Failed to load certificate", {
          description: "There was an error retrieving this certificate. Please try again later."
        });
      }
    };

    fetchCertificate();
  }, [id]);

  const handleDownload = () => {
    toast.success("Certificate download started");
  };

  const getTimeRemaining = () => {
    if (!certificateData) return null;
    
    const now = new Date();
    const expiry = new Date(certificateData.accessExpiry);
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 0) return "Expired";
    if (diffDays === 1) return "1 day";
    return `${diffDays} days`;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center min-h-[80vh]">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
            <h2 className="text-xl font-semibold mb-2">Loading Certificate</h2>
            <p className="text-muted-foreground">Retrieving from blockchain...</p>
          </div>
        ) : certificateData ? (
          <>
            <div className="max-w-4xl mx-auto mb-8">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                <div>
                  <span className="text-sm text-muted-foreground">SHARED CERTIFICATE</span>
                  <h1 className="text-2xl sm:text-3xl font-bold">Certificate Preview</h1>
                </div>
                <div className="flex items-center gap-2">
                  {isVerified ? (
                    <div className="flex items-center text-green-600 text-sm">
                      <Shield className="h-4 w-4 mr-1" />
                      <span>Blockchain Verified</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-amber-600 text-sm">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Verifying...</span>
                    </div>
                  )}
                  
                  <Button variant="outline" size="sm" onClick={() => setShowVerificationDetails(true)}>
                    View Details
                  </Button>
                </div>
              </div>

              <Card className="mb-8 overflow-hidden">
                {/* Certificate Banner */}
                <div className="bg-gradient-to-r from-primary/20 to-accent/20 p-6 flex items-center justify-between">
                  <div className="flex items-center">
                    <Award className="h-10 w-10 text-primary mr-4" />
                    <div>
                      <h2 className="text-2xl font-bold">{certificateData.title}</h2>
                      <p className="text-sm">Issued by {certificateData.issuer}</p>
                    </div>
                  </div>
                  <div className="bg-background/90 backdrop-blur-sm rounded-lg px-4 py-2 text-sm border border-border">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1.5 text-muted-foreground" />
                      <span>Access expires in {getTimeRemaining()}</span>
                    </div>
                  </div>
                </div>
                
                {/* Certificate Content */}
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-[1fr_2fr] gap-6">
                    {/* Certificate Image */}
                    <div>
                      <div 
                        className="aspect-[3/4] rounded-lg bg-muted bg-cover bg-center relative"
                        style={{ backgroundImage: `url(${certificateData.imageUrl})` }}
                      >
                        <div className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-sm">
                          <div className="text-center p-4">
                            <Lock className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
                            <p className="text-sm font-medium">Preview Image</p>
                            <p className="text-xs text-muted-foreground">Full certificate available for download</p>
                          </div>
                        </div>
                      </div>
                      <div className="mt-4">
                        <Button className="w-full" onClick={handleDownload}>
                          <Download className="h-4 w-4 mr-2" /> Download Certificate
                        </Button>
                      </div>
                    </div>
                    
                    {/* Certificate Details */}
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Certificate Details</h3>
                        <ul className="space-y-3">
                          <li className="flex justify-between">
                            <span className="text-muted-foreground">Certificate ID:</span>
                            <span className="font-medium">{certificateData.id}</span>
                          </li>
                          <li className="flex justify-between">
                            <span className="text-muted-foreground">Recipient:</span>
                            <span className="font-medium">{certificateData.recipient}</span>
                          </li>
                          <li className="flex justify-between">
                            <span className="text-muted-foreground">Issue Date:</span>
                            <span className="font-medium">
                              {new Date(certificateData.issueDate).toLocaleDateString()}
                            </span>
                          </li>
                          {certificateData.expiryDate && (
                            <li className="flex justify-between">
                              <span className="text-muted-foreground">Expiry Date:</span>
                              <span className="font-medium">
                                {new Date(certificateData.expiryDate).toLocaleDateString()}
                              </span>
                            </li>
                          )}
                        </ul>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Description</h3>
                        <p className="text-muted-foreground">{certificateData.description}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Blockchain Verification</h3>
                        <Card className="p-3 bg-muted/20 border-muted">
                          <div className="flex items-center">
                            {isVerified ? (
                              <div className="h-8 w-8 rounded-full bg-green-100 dark:bg-green-900/20 text-green-600 flex items-center justify-center mr-3">
                                <Check className="h-5 w-5" />
                              </div>
                            ) : (
                              <div className="h-8 w-8 rounded-full bg-amber-100 dark:bg-amber-900/20 text-amber-600 flex items-center justify-center mr-3">
                                <Clock className="h-5 w-5" />
                              </div>
                            )}
                            
                            <div>
                              <h4 className="font-medium">
                                {isVerified ? "Certificate Authenticated" : "Verifying Certificate"}
                              </h4>
                              <p className="text-xs text-muted-foreground">
                                {isVerified 
                                  ? "This certificate has been verified on the Ethereum blockchain"
                                  : "Checking certificate authenticity..."}
                              </p>
                            </div>
                            
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="ml-auto"
                              onClick={() => setShowVerificationDetails(true)}
                            >
                              Details
                            </Button>
                          </div>
                        </Card>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Additional Actions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="p-4 hover:border-primary/50 transition-colors cursor-pointer">
                  <div className="flex flex-col items-center text-center">
                    <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-2">
                      <User className="h-5 w-5" />
                    </div>
                    <h3 className="font-medium">View Issuer</h3>
                    <p className="text-xs text-muted-foreground">See issuer details</p>
                  </div>
                </Card>
                
                <Card className="p-4 hover:border-primary/50 transition-colors cursor-pointer">
                  <div className="flex flex-col items-center text-center">
                    <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-2">
                      <Shield className="h-5 w-5" />
                    </div>
                    <h3 className="font-medium">Verify Manually</h3>
                    <p className="text-xs text-muted-foreground">Check blockchain record</p>
                  </div>
                </Card>
                
                <Card className="p-4 hover:border-primary/50 transition-colors cursor-pointer">
                  <div className="flex flex-col items-center text-center">
                    <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-2">
                      <ExternalLink className="h-5 w-5" />
                    </div>
                    <h3 className="font-medium">Share</h3>
                    <p className="text-xs text-muted-foreground">Share this certificate</p>
                  </div>
                </Card>
                
                <Card className="p-4 hover:border-primary/50 transition-colors cursor-pointer">
                  <div className="flex flex-col items-center text-center">
                    <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-2">
                      <Smile className="h-5 w-5" />
                    </div>
                    <h3 className="font-medium">Provide Feedback</h3>
                    <p className="text-xs text-muted-foreground">Rate this certificate</p>
                  </div>
                </Card>
              </div>
            </div>

            {/* E-Certify Footer */}
            <div className="text-center border-t border-border pt-6 mt-6">
              <p className="text-muted-foreground">
                Powered by <span className="font-semibold">E-Certify</span> - Blockchain Certificate Verification Platform
              </p>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center min-h-[80vh]">
            <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/20 text-red-600 flex items-center justify-center mb-4">
              <Lock className="h-8 w-8" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Certificate Not Found</h2>
            <p className="text-muted-foreground mb-6">
              This certificate could not be found or the access link has expired.
            </p>
            <Button asChild>
              <a href="/">Return to Home</a>
            </Button>
          </div>
        )}
      </div>

      {/* Verification Details Dialog */}
      <Dialog open={showVerificationDetails} onOpenChange={setShowVerificationDetails}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Blockchain Verification Details</DialogTitle>
            <DialogDescription>
              Technical details about the certificate's blockchain verification
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div>
              <h3 className="text-sm font-medium">Certificate Hash</h3>
              <p className="text-sm font-mono bg-muted p-2 rounded-md mt-1 overflow-auto">
                {certificateData?.blockchainHash}
              </p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium">IPFS Storage Location</h3>
              <p className="text-sm font-mono bg-muted p-2 rounded-md mt-1 overflow-auto">
                {certificateData?.ipfsHash}
              </p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium">Verification Method</h3>
              <div className="space-y-1 mt-1">
                <div className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-1.5" />
                  <span className="text-sm">Ethereum Smart Contract Verification</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-1.5" />
                  <span className="text-sm">Multi-signature Authentication</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-1.5" />
                  <span className="text-sm">IPFS Content Integrity Check</span>
                </div>
              </div>
            </div>
            
            <Card className="p-3 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 mt-4">
              <div className="flex items-start">
                <Shield className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                <div>
                  <h4 className="font-medium text-green-700 dark:text-green-300">Certificate is Authentic</h4>
                  <p className="text-xs text-green-600 dark:text-green-400">
                    This certificate was issued by {certificateData?.issuer} on {certificateData?.issueDate && new Date(certificateData.issueDate).toLocaleDateString()} 
                    and has been verified for authenticity.
                  </p>
                </div>
              </div>
            </Card>
          </div>
          
          <DialogFooter>
            <Button onClick={() => setShowVerificationDetails(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CertificateView;
