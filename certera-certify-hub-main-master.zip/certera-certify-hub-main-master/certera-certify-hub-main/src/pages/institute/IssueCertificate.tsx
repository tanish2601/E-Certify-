
import { useState } from "react";
import { useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { toast } from "@/components/ui/sonner";
import { useWeb3 } from "@/context/Web3Context";
import { Upload, CheckCircle, AlertCircle, Loader2 } from "lucide-react";

const IssueCertificate = () => {
  const location = useLocation();
  const { account } = useWeb3();
  const searchParams = new URLSearchParams(location.search);
  const preSelectedStudent = searchParams.get("student") || "";

  const [step, setStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [formData, setFormData] = useState({
    student: preSelectedStudent,
    certificateType: "",
    title: "",
    description: "",
    issueDate: new Date().toISOString().split("T")[0],
    expiryDate: "",
    additionalInfo: "",
    file: null as File | null
  });

  // List of students (would come from API in a real app)
  const students = [
    { id: "ST001", name: "Sarah Johnson" },
    { id: "ST002", name: "James Wilson" },
    { id: "ST003", name: "Emma Davis" },
    { id: "ST004", name: "Alex Chen" },
    { id: "ST005", name: "Olivia Martinez" }
  ];

  // Certificate types
  const certificateTypes = [
    { id: "degree", name: "Degree Certificate" },
    { id: "course", name: "Course Completion" },
    { id: "certificate", name: "Certification" },
    { id: "award", name: "Award/Achievement" }
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, file: e.target.files![0] }));
    }
  };

  const validateForm = () => {
    const requiredFields = ['student', 'certificateType', 'title', 'issueDate'];
    for (const field of requiredFields) {
      if (!formData[field as keyof typeof formData]) {
        toast.error("Missing required information", {
          description: `Please fill out all required fields before proceeding.`
        });
        return false;
      }
    }
    
    if (!formData.file) {
      toast.error("Missing certificate file", {
        description: "Please upload a certificate file before proceeding."
      });
      return false;
    }
    
    return true;
  };

  const handleNext = () => {
    if (validateForm()) {
      setStep(2);
    }
  };

  const handleBack = () => {
    setStep(1);
  };

  const handleInitializeIssuance = () => {
    setIsInitialized(true);
  };

  const handleSubmit = () => {
    setIsProcessing(true);
    
    // Simulate blockchain transaction
    setTimeout(() => {
      toast.success("Certificate issued successfully", {
        description: "The certificate has been uploaded to IPFS and recorded on the blockchain."
      });
      
      setIsProcessing(false);
      setStep(3);
    }, 3000);
  };

  const getSelectedStudentName = () => {
    const student = students.find(s => s.id === formData.student);
    return student ? student.name : "Selected Student";
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Issue Certificate</h1>
        <p className="text-muted-foreground mt-2">
          Create and issue blockchain-verified certificates to students
        </p>
      </div>

      <Tabs defaultValue="issue" className="space-y-8">
        <TabsList>
          <TabsTrigger value="issue">Issue Certificate</TabsTrigger>
          <TabsTrigger value="bulk">Bulk Issue</TabsTrigger>
          <TabsTrigger value="history">Issuance History</TabsTrigger>
        </TabsList>

        <TabsContent value="issue">
          <Card className="mb-6">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">
                  {step === 1 && "Certificate Details"}
                  {step === 2 && "Review & Sign"}
                  {step === 3 && "Certificate Issued"}
                </h2>
                
                {step < 3 && (
                  <div className="flex items-center">
                    <span className="text-sm text-muted-foreground mr-4">Step {step} of 2</span>
                    <div className="w-20 h-2 bg-muted rounded-full">
                      <div 
                        className="h-2 bg-primary rounded-full" 
                        style={{ width: step === 1 ? "50%" : "100%" }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Step 1: Certificate Details Form */}
              {step === 1 && (
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="student">Student</Label>
                      <Select 
                        value={formData.student} 
                        onValueChange={(value) => handleSelectChange("student", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a student" />
                        </SelectTrigger>
                        <SelectContent>
                          {students.map(student => (
                            <SelectItem key={student.id} value={student.id}>
                              {student.name} ({student.id})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="certificateType">Certificate Type</Label>
                      <Select 
                        value={formData.certificateType} 
                        onValueChange={(value) => handleSelectChange("certificateType", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select certificate type" />
                        </SelectTrigger>
                        <SelectContent>
                          {certificateTypes.map(type => (
                            <SelectItem key={type.id} value={type.id}>
                              {type.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="title">Certificate Title</Label>
                      <Input 
                        id="title"
                        name="title"
                        placeholder="e.g. Bachelor of Computer Science"
                        value={formData.title}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="issueDate">Issue Date</Label>
                      <Input 
                        id="issueDate"
                        name="issueDate"
                        type="date"
                        value={formData.issueDate}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="expiryDate">Expiry Date (Optional)</Label>
                      <Input 
                        id="expiryDate"
                        name="expiryDate"
                        type="date"
                        value={formData.expiryDate}
                        onChange={handleChange}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Certificate Description</Label>
                    <Textarea 
                      id="description"
                      name="description"
                      placeholder="Provide details about the certificate, course curriculum, achievements, etc."
                      rows={3}
                      value={formData.description}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="certificate-file">Upload Certificate File</Label>
                    <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
                      <input
                        id="certificate-file"
                        type="file"
                        className="hidden"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={handleFileChange}
                      />
                      
                      {!formData.file ? (
                        <div>
                          <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
                          <p className="mt-2 text-sm font-medium">
                            Drag and drop or click to upload
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            PDF, PNG or JPG up to 10MB
                          </p>
                          <Button
                            variant="outline"
                            className="mt-4"
                            onClick={() => document.getElementById("certificate-file")?.click()}
                          >
                            Select File
                          </Button>
                        </div>
                      ) : (
                        <div className="text-left flex items-center">
                          <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                          <div>
                            <p className="font-medium">{formData.file.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {(formData.file.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="ml-auto"
                            onClick={() => setFormData(prev => ({ ...prev, file: null }))}
                          >
                            Change
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="additionalInfo">Additional Information (Optional)</Label>
                    <Textarea 
                      id="additionalInfo"
                      name="additionalInfo"
                      placeholder="Any additional details..."
                      rows={2}
                      value={formData.additionalInfo}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="flex justify-end">
                    <Button onClick={handleNext}>
                      Continue to Review
                    </Button>
                  </div>
                </form>
              )}

              {/* Step 2: Review and Sign */}
              {step === 2 && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="p-4 border border-border">
                      <h3 className="font-medium mb-4">Certificate Information</h3>
                      <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Certificate Type:</span>
                          <span className="font-medium">
                            {certificateTypes.find(t => t.id === formData.certificateType)?.name}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Title:</span>
                          <span className="font-medium">{formData.title}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Issue Date:</span>
                          <span className="font-medium">{new Date(formData.issueDate).toLocaleDateString()}</span>
                        </div>
                        {formData.expiryDate && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Expiry Date:</span>
                            <span className="font-medium">{new Date(formData.expiryDate).toLocaleDateString()}</span>
                          </div>
                        )}
                        <div className="pt-2">
                          <span className="text-muted-foreground">Description:</span>
                          <p className="mt-1">{formData.description}</p>
                        </div>
                      </div>
                    </Card>
                    
                    <Card className="p-4 border border-border">
                      <h3 className="font-medium mb-4">Issuance Details</h3>
                      <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Student:</span>
                          <span className="font-medium">{getSelectedStudentName()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Issuer:</span>
                          <span className="font-medium truncate max-w-[200px]">{account}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">File:</span>
                          <span className="font-medium">{formData.file?.name}</span>
                        </div>
                      </div>
                      
                      <div className="mt-6">
                        <h3 className="font-medium mb-2">Storage Method</h3>
                        <div className="space-y-1 text-sm">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-1.5" />
                            <span>IPFS encrypted storage</span>
                          </div>
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-1.5" />
                            <span>Ethereum blockchain verification</span>
                          </div>
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-1.5" />
                            <span>Multi-signature security</span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>
                  
                  {!isInitialized ? (
                    <div className="mt-6">
                      <Card className="p-4 bg-muted/20">
                        <div className="flex items-start">
                          <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5 mr-2" />
                          <div>
                            <h4 className="font-medium">Certificate Verification</h4>
                            <p className="text-sm text-muted-foreground mt-1">
                              By proceeding, you confirm that all information provided is accurate. 
                              The certificate will be permanently stored on IPFS and its hash will be 
                              recorded on the blockchain. This action cannot be undone.
                            </p>
                          </div>
                        </div>
                        <div className="mt-4 text-center">
                          <Button onClick={handleInitializeIssuance} className="w-full sm:w-auto">
                            Initialize Certificate Issuance
                          </Button>
                        </div>
                      </Card>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <Card className="p-4 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
                        <div className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                          <div>
                            <h4 className="font-medium text-green-700 dark:text-green-300">Ready to Issue</h4>
                            <p className="text-sm text-green-600 dark:text-green-400 mt-1">
                              Certificate data has been validated. You can now proceed to sign the transaction 
                              and issue the certificate on the blockchain.
                            </p>
                          </div>
                        </div>
                      </Card>
                      
                      <div className="flex justify-between">
                        <Button variant="outline" onClick={handleBack} disabled={isProcessing}>
                          Back
                        </Button>
                        <Button 
                          onClick={handleSubmit} 
                          disabled={isProcessing}
                          className="min-w-[180px]"
                        >
                          {isProcessing ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                            </>
                          ) : (
                            "Sign & Issue Certificate"
                          )}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Step 3: Success */}
              {step === 3 && (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-50 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="h-8 w-8 text-green-500" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">Certificate Issued Successfully</h2>
                  <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                    The certificate has been successfully issued to {getSelectedStudentName()}.
                    The student will be notified about the new certificate.
                  </p>
                  
                  <div className="bg-muted/20 p-4 rounded-lg text-left max-w-md mx-auto mb-6">
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Transaction Hash:</span>
                        <span className="font-mono">0xabc...123</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">IPFS Hash:</span>
                        <span className="font-mono">QmUy...X7p</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Certificate ID:</span>
                        <span className="font-mono">CERT-2025-042</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row justify-center gap-3">
                    <Button variant="outline">View Certificate</Button>
                    <Button onClick={() => window.location.href = "/institute/issue"}>
                      Issue Another Certificate
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="bulk">
          <Card className="p-6">
            <div className="text-center py-8">
              <h3 className="text-lg font-medium mb-2">Bulk Certificate Issuance</h3>
              <p className="text-muted-foreground max-w-md mx-auto mb-6">
                Issue multiple certificates at once by uploading a CSV file with 
                student details and certificate information.
              </p>
              
              <div className="border-2 border-dashed border-muted rounded-lg p-10 max-w-md mx-auto">
                <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm font-medium">
                  Drop your CSV file here or click to browse
                </p>
                <p className="text-xs text-muted-foreground mt-1 mb-4">
                  Download our <a href="#" className="text-primary">template CSV file</a> for formatting
                </p>
                <Button variant="outline">Select File</Button>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Recent Certificate Issuance History</h3>
            
            <div className="border border-border rounded-lg divide-y divide-border">
              {[
                {
                  id: "CERT-2025-041",
                  title: "Machine Learning Fundamentals",
                  student: "Emma Davis",
                  date: "2025-04-20",
                  hash: "0xdef...789"
                },
                {
                  id: "CERT-2025-040",
                  title: "Advanced Programming",
                  student: "James Wilson",
                  date: "2025-04-18",
                  hash: "0xabc...456"
                },
                {
                  id: "CERT-2025-039",
                  title: "Cloud Computing",
                  student: "Sarah Johnson",
                  date: "2025-04-15",
                  hash: "0xghi...123"
                },
              ].map((cert, index) => (
                <div key={index} className="p-4 flex flex-col md:flex-row md:items-center md:justify-between">
                  <div>
                    <h4 className="font-medium">{cert.title}</h4>
                    <p className="text-sm text-muted-foreground">
                      Issued to {cert.student} on {new Date(cert.date).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center mt-2 md:mt-0">
                    <span className="text-xs font-mono text-muted-foreground mr-3">{cert.hash}</span>
                    <Button size="sm" variant="outline">View</Button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 text-center">
              <Button variant="outline">View All History</Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default IssueCertificate;
