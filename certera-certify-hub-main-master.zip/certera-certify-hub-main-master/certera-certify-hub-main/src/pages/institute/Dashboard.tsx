
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useUserStore } from "@/store/userStore";
import { Link } from "react-router-dom";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer
} from "recharts";
import {
  Bell,
  Award,
  Users,
  Clock,
  BarChart2,
  CheckCircle
} from "lucide-react";

const InstituteDashboard = () => {
  const { profile } = useUserStore();
  const [stats] = useState({
    totalStudents: 128,
    certificatesIssued: 256,
    pendingRequests: 15,
    certificatesViewed: 194
  });

  const certificateData = [
    { month: "Jan", issued: 12, viewed: 8 },
    { month: "Feb", issued: 19, viewed: 15 },
    { month: "Mar", issued: 25, viewed: 20 },
    { month: "Apr", issued: 15, viewed: 18 },
    { month: "May", issued: 30, viewed: 25 },
    { month: "Jun", issued: 28, viewed: 23 },
    { month: "Jul", issued: 32, viewed: 30 }
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Welcome, {profile?.name}</h1>
        <p className="text-muted-foreground mt-2">
          Manage your institution's certificates and student requests
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="p-5">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-4">
              <Award className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Certificates Issued</p>
              <h3 className="text-2xl font-bold">{stats.certificatesIssued}</h3>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="mt-4 w-full" asChild>
            <Link to="/institute/issue">Issue New</Link>
          </Button>
        </Card>

        <Card className="p-5">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-4">
              <Users className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Students</p>
              <h3 className="text-2xl font-bold">{stats.totalStudents}</h3>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="mt-4 w-full" asChild>
            <Link to="/institute/students">View All</Link>
          </Button>
        </Card>

        <Card className="p-5">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-4">
              <Clock className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending Requests</p>
              <h3 className="text-2xl font-bold">{stats.pendingRequests}</h3>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="mt-4 w-full" asChild>
            <Link to="/institute/requests">Review</Link>
          </Button>
        </Card>

        <Card className="p-5">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-4">
              <Bell className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Certificates Viewed</p>
              <h3 className="text-2xl font-bold">{stats.certificatesViewed}</h3>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="mt-4 w-full">
            View Analytics
          </Button>
        </Card>
      </div>

      {/* Charts and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Certificate Activity Chart */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold">Certificate Activity</h2>
              <p className="text-sm text-muted-foreground">Monthly certificates issued and viewed</p>
            </div>
            <Button variant="outline" size="sm">
              <BarChart2 className="h-4 w-4 mr-2" /> Analytics
            </Button>
          </div>
          
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={certificateData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
                <XAxis dataKey="month" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <RechartsTooltip />
                <Line
                  type="monotone"
                  dataKey="issued"
                  name="Certificates Issued"
                  stroke="#2563eb"
                  strokeWidth={2}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="viewed"
                  name="Certificates Viewed"
                  stroke="#10b981"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Recent Activity</h2>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
          
          <div className="space-y-4">
            {[
              {
                type: "Certificate Issued",
                details: "Advanced Data Structures certificate issued to Sarah Johnson",
                time: "2 hours ago",
                icon: <Award className="h-5 w-5" />
              },
              {
                type: "New Request",
                details: "Alex Chen requested a Machine Learning certificate",
                time: "Yesterday",
                icon: <Clock className="h-5 w-5" />
              },
              {
                type: "Certificate Verified",
                details: "Google HR verified James Wilson's Software Engineering certificate",
                time: "2 days ago",
                icon: <CheckCircle className="h-5 w-5" />
              },
              {
                type: "New Student",
                details: "Emma Davis registered and linked their wallet",
                time: "3 days ago",
                icon: <Users className="h-5 w-5" />
              }
            ].map((item, index) => (
              <div key={index} className="flex items-start">
                <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-4 shrink-0">
                  {item.icon}
                </div>
                <div>
                  <p className="font-medium">{item.type}</p>
                  <p className="text-sm text-muted-foreground">{item.details}</p>
                  <p className="text-xs text-muted-foreground mt-1">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 text-center">
            <Button variant="outline" size="sm">Load More</Button>
          </div>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-6">Quick Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { icon: <Award className="h-6 w-6" />, label: "Issue Certificate", link: "/institute/issue" },
            { icon: <Users className="h-6 w-6" />, label: "Manage Students", link: "/institute/students" },
            { icon: <Clock className="h-6 w-6" />, label: "Review Requests", link: "/institute/requests" },
            { icon: <BarChart2 className="h-6 w-6" />, label: "Analytics", link: "#" },
            { icon: <CheckCircle className="h-6 w-6" />, label: "Verify Certificate", link: "#" },
            { icon: <Bell className="h-6 w-6" />, label: "Notifications", link: "#" }
          ].map((action, index) => (
            <Card key={index} className="p-4 text-center hover:border-primary/50 transition-colors cursor-pointer">
              <Link to={action.link} className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-3">
                  {action.icon}
                </div>
                <p className="text-sm font-medium">{action.label}</p>
              </Link>
            </Card>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default InstituteDashboard;
