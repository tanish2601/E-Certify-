
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { toast } from "@/components/ui/sonner";
import { useUserStore } from "@/store/userStore";
import { useWeb3 } from "@/context/Web3Context";

const InstituteProfile = () => {
  const { profile, setProfile } = useUserStore();
  const { account } = useWeb3();

  const [formData, setFormData] = useState({
    name: profile?.name || "",
    email: profile?.email || "",
    phone: "+1 987 654 3210",
    website: "https://techinstitute.edu",
    description: "Tech Institute is a leading educational institution specializing in computer science, blockchain technology, and artificial intelligence education. Established in 2010, we have awarded over 10,000 certificates in various technical disciplines.",
    location: "San Francisco, CA",
    type: "University",
    registrationNumber: "INST-12345"
  });

  const [settings, setSettings] = useState({
    autoApproveStudents: false,
    requireStudentSignature: true,
    publicProfile: true,
    certificateNotifications: true
  });

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSettingChange = (setting: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [setting]: !prev[setting] }));
  };

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Update profile in store
    if (profile) {
      setProfile({
        ...profile,
        name: formData.name,
        email: formData.email
      });
    }
    
    toast.success("Institute profile updated successfully");
  };

  const handleSettingsUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Settings updated successfully");
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Institute Profile</h1>
        <p className="text-muted-foreground mt-2">
          Manage your institute information and settings
        </p>
      </div>

      <Tabs defaultValue="profile" className="space-y-8">
        <TabsList className="grid w-full grid-cols-3 md:w-auto">
          <TabsTrigger value="profile">Institute Info</TabsTrigger>
          <TabsTrigger value="branding">Branding</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        {/* Institute Profile Tab */}
        <TabsContent value="profile">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="col-span-1 p-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-32 h-32 rounded-full bg-primary/10 text-primary flex items-center justify-center text-4xl mb-4">
                  {formData.name.charAt(0)}
                </div>
                <h2 className="text-xl font-semibold">{formData.name}</h2>
                <p className="text-muted-foreground">{formData.email}</p>
                <p className="text-xs mt-2 bg-primary/10 text-primary px-2 py-1 rounded-full">Verified Institute</p>
                
                <div className="mt-6 w-full">
                  <div className="text-sm space-y-3">
                    <div>
                      <p className="text-muted-foreground">Wallet Address</p>
                      <p className="font-mono text-xs truncate">{account}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Registration Number</p>
                      <p>{formData.registrationNumber}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Account Status</p>
                      <p className="text-green-600">Active</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="col-span-1 md:col-span-2 p-6">
              <h2 className="text-xl font-semibold mb-6">Institute Information</h2>
              <form onSubmit={handleProfileUpdate} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Institute Name</Label>
                    <Input 
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleProfileChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleProfileChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input 
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleProfileChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="website">Website</Label>
                    <Input 
                      id="website"
                      name="website"
                      value={formData.website}
                      onChange={handleProfileChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input 
                      id="location"
                      name="location"
                      value={formData.location}
                      onChange={handleProfileChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="type">Institution Type</Label>
                    <Input 
                      id="type"
                      name="type"
                      value={formData.type}
                      onChange={handleProfileChange}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea 
                    id="description"
                    name="description"
                    rows={4}
                    value={formData.description}
                    onChange={handleProfileChange}
                  />
                </div>
                
                <div className="flex justify-end">
                  <Button type="submit">
                    Update Profile
                  </Button>
                </div>
              </form>
            </Card>
          </div>
        </TabsContent>

        {/* Branding Tab */}
        <TabsContent value="branding">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-6">Certificate Branding</h2>
            
            <div className="space-y-8">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Logo & Colors</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="mb-2 block">Institute Logo</Label>
                    <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                      <div className="w-24 h-24 bg-primary/10 text-primary flex items-center justify-center text-4xl mx-auto">
                        {formData.name.charAt(0)}
                      </div>
                      <Button variant="outline" size="sm" className="mt-4">
                        Upload Logo
                      </Button>
                      <p className="text-xs text-muted-foreground mt-2">
                        Recommended size: 512x512px, PNG or SVG
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Primary Color</Label>
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-primary rounded-full"></div>
                        <Input value="#2563EB" className="font-mono" />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Secondary Color</Label>
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-accent rounded-full"></div>
                        <Input value="#10B981" className="font-mono" />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Accent Color</Label>
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-amber-500 rounded-full"></div>
                        <Input value="#F59E0B" className="font-mono" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4 pt-4 border-t border-border">
                <h3 className="text-lg font-medium">Certificate Template</h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {[
                    { name: "Modern", selected: true },
                    { name: "Classic", selected: false },
                    { name: "Professional", selected: false },
                  ].map((template, i) => (
                    <div 
                      key={i}
                      className={`border rounded-lg p-4 text-center ${
                        template.selected ? "border-primary bg-primary/5" : "border-border"
                      }`}
                    >
                      <div className="aspect-[8.5/11] bg-card rounded-md mb-3 flex items-center justify-center">
                        <span className="text-sm font-medium">{template.name}</span>
                      </div>
                      <Button 
                        size="sm" 
                        variant={template.selected ? "default" : "outline"}
                        className="w-full"
                      >
                        {template.selected ? "Selected" : "Select"}
                      </Button>
                    </div>
                  ))}
                </div>
                
                <p className="text-sm text-muted-foreground mt-2">
                  Custom templates can be uploaded in the Pro version of E-Certify.
                </p>
              </div>
              
              <div className="pt-4 flex justify-end">
                <Button>Save Branding Settings</Button>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-6">Institute Settings</h2>
            <form onSubmit={handleSettingsUpdate} className="space-y-6">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="autoApprove">Auto-Approve Students</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically approve student registration requests
                    </p>
                  </div>
                  <Switch 
                    id="autoApprove" 
                    checked={settings.autoApproveStudents}
                    onCheckedChange={() => handleSettingChange('autoApproveStudents')}
                  />
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div className="space-y-0.5">
                    <Label htmlFor="requireSignature">Require Student Signature</Label>
                    <p className="text-sm text-muted-foreground">
                      Require student wallet signature for certificate issuance
                    </p>
                  </div>
                  <Switch 
                    id="requireSignature" 
                    checked={settings.requireStudentSignature}
                    onCheckedChange={() => handleSettingChange('requireStudentSignature')}
                  />
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div className="space-y-0.5">
                    <Label htmlFor="publicProfile">Public Institute Profile</Label>
                    <p className="text-sm text-muted-foreground">
                      Make your institute profile publicly visible
                    </p>
                  </div>
                  <Switch 
                    id="publicProfile" 
                    checked={settings.publicProfile}
                    onCheckedChange={() => handleSettingChange('publicProfile')}
                  />
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div className="space-y-0.5">
                    <Label htmlFor="notifications">Certificate Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive notifications when certificates are viewed
                    </p>
                  </div>
                  <Switch 
                    id="notifications" 
                    checked={settings.certificateNotifications}
                    onCheckedChange={() => handleSettingChange('certificateNotifications')}
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t border-border">
                <h3 className="text-lg font-medium mb-4">Security Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="recoveryEmail">Recovery Email</Label>
                    <Input 
                      id="recoveryEmail"
                      type="email"
                      value={profile?.email || ""}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="managedAccounts">Number of Managed Accounts</Label>
                    <Input 
                      id="managedAccounts"
                      type="number"
                      min="1"
                      max="5"
                      value="2"
                      readOnly
                    />
                    <p className="text-xs text-muted-foreground">
                      You can add more managed accounts in the Pro version
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-border">
                <h3 className="text-lg font-medium mb-4">Data & Privacy</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Data Storage Region</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Button variant="outline" className="justify-start">
                        <div className="w-4 h-4 border-2 border-primary rounded-full mr-2 flex items-center justify-center">
                          <div className="w-2 h-2 bg-primary rounded-full"></div>
                        </div>
                        Global (Default)
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <div className="w-4 h-4 border-2 border-muted-foreground rounded-full mr-2"></div>
                        EU Only
                      </Button>
                      <Button variant="outline" className="justify-start">
                        <div className="w-4 h-4 border-2 border-muted-foreground rounded-full mr-2"></div>
                        US Only
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button type="submit">
                  Save Settings
                </Button>
              </div>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default InstituteProfile;
