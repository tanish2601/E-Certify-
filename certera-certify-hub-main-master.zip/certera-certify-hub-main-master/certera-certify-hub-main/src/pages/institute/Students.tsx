
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "@/components/ui/sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Search,
  MoreHorizontal,
  Award,
  UserPlus,
  Loader2,
  Check
} from "lucide-react";

const Students = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddStudentDialogOpen, setIsAddStudentDialogOpen] = useState(false);
  const [isVerifyingWallet, setIsVerifyingWallet] = useState(false);
  const [newStudentWallet, setNewStudentWallet] = useState("");

  const students = [
    {
      id: "ST001",
      name: "Sarah Johnson",
      walletAddress: "0xaBcD...1234",
      joined: "2024-01-15",
      certificatesIssued: 5,
      status: "Active",
      isVerified: true
    },
    {
      id: "ST002",
      name: "James Wilson",
      walletAddress: "0xeFgH...5678",
      joined: "2024-02-03",
      certificatesIssued: 3,
      status: "Active",
      isVerified: true
    },
    {
      id: "ST003",
      name: "Emma Davis",
      walletAddress: "0xIjKl...9012",
      joined: "2024-02-25",
      certificatesIssued: 2,
      status: "Active",
      isVerified: false
    },
    {
      id: "ST004",
      name: "Alex Chen",
      walletAddress: "0xMnOp...3456",
      joined: "2024-03-10",
      certificatesIssued: 1,
      status: "Pending",
      isVerified: false
    },
    {
      id: "ST005",
      name: "Olivia Martinez",
      walletAddress: "0xQrSt...7890",
      joined: "2024-03-22",
      certificatesIssued: 0,
      status: "Active",
      isVerified: true
    }
  ];

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.walletAddress.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleIssueClick = (studentId: string) => {
    // Navigate to issue certificate page with pre-selected student
    window.location.href = `/institute/issue?student=${studentId}`;
  };

  const handleVerifyClick = (studentId: string) => {
    toast.success("Verification email sent", {
      description: `A verification link has been sent to the student with ID ${studentId}`
    });
  };

  const handleVerifyWallet = () => {
    if (!newStudentWallet) {
      toast.error("Please enter a wallet address");
      return;
    }
    
    setIsVerifyingWallet(true);
    
    // Simulate verification process
    setTimeout(() => {
      toast.success("Wallet verified successfully", {
        description: "An invitation has been sent to the student"
      });
      setIsVerifyingWallet(false);
      setNewStudentWallet("");
      setIsAddStudentDialogOpen(false);
    }, 2000);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Students</h1>
          <p className="text-muted-foreground mt-2">
            Manage students and issued certificates
          </p>
        </div>
        <Button onClick={() => setIsAddStudentDialogOpen(true)}>
          <UserPlus className="h-4 w-4 mr-2" /> Add Student
        </Button>
      </div>

      <Card className="mb-8">
        <div className="p-4 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-grow">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, ID or wallet address..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setSearchTerm("")}>
              Reset
            </Button>
          </div>
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Wallet Address</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead>Certificates</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredStudents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8">
                  No students found matching your search criteria
                </TableCell>
              </TableRow>
            ) : (
              filteredStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.id}</TableCell>
                  <TableCell>{student.name}</TableCell>
                  <TableCell className="font-mono text-sm">
                    {student.walletAddress}
                    {student.isVerified && (
                      <span className="inline-flex ml-2 items-center">
                        <Check className="w-3 h-3 text-green-500" />
                      </span>
                    )}
                  </TableCell>
                  <TableCell>{new Date(student.joined).toLocaleDateString()}</TableCell>
                  <TableCell>{student.certificatesIssued}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      student.status === "Active" 
                        ? "bg-green-100 text-green-800" 
                        : "bg-yellow-100 text-yellow-800"
                    }`}>
                      {student.status}
                    </span>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="w-4 h-4" />
                          <span className="sr-only">Actions</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleIssueClick(student.id)}>
                          <Award className="w-4 h-4 mr-2" /> Issue Certificate
                        </DropdownMenuItem>
                        {!student.isVerified && (
                          <DropdownMenuItem onClick={() => handleVerifyClick(student.id)}>
                            <Check className="w-4 h-4 mr-2" /> Verify Student
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                        <DropdownMenuItem>View Certificates</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>

      {/* Add Student Dialog */}
      <Dialog open={isAddStudentDialogOpen} onOpenChange={setIsAddStudentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Student</DialogTitle>
            <DialogDescription>
              Enter the student's Ethereum wallet address to send an invitation
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="wallet-address">
                Student Ethereum Wallet Address
              </label>
              <Input
                id="wallet-address"
                placeholder="0x..."
                value={newStudentWallet}
                onChange={(e) => setNewStudentWallet(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                The student will receive an invitation to connect their wallet and complete registration
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddStudentDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleVerifyWallet}
              disabled={isVerifyingWallet}
            >
              {isVerifyingWallet ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying
                </>
              ) : (
                "Send Invitation"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Students;
