
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { toast } from "@/components/ui/sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { 
  Search, 
  Check, 
  X, 
  Info,
  Loader2
} from "lucide-react";

const Requests = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [viewRequestDetails, setViewRequestDetails] = useState<null | {
    id: string;
    student: string;
    walletAddress: string;
    certificateType: string;
    title: string;
    description: string;
    requestDate: string;
  }>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Certificate requests data
  const certificateRequests = [
    {
      id: "REQ-001",
      student: "Alex Chen",
      walletAddress: "0xMnOp...3456",
      certificateType: "Course Completion",
      title: "Machine Learning Certificate",
      description: "Completed advanced machine learning course with 95% grade",
      requestDate: "2025-04-18",
      status: "Pending"
    },
    {
      id: "REQ-002",
      student: "Emma Davis",
      walletAddress: "0xIjKl...9012",
      certificateType: "Skill Verification",
      title: "Blockchain Development Skills",
      description: "Completed blockchain development course and built a DApp project",
      requestDate: "2025-04-16",
      status: "Pending"
    },
    {
      id: "REQ-003",
      student: "Sarah Johnson",
      walletAddress: "0xaBcD...1234",
      certificateType: "Workshop Completion",
      title: "AI Ethics Workshop",
      description: "Attended and completed the AI ethics workshop on April 15",
      requestDate: "2025-04-15",
      status: "Pending"
    }
  ];

  // Completed requests
  const completedRequests = [
    {
      id: "REQ-004",
      student: "James Wilson",
      walletAddress: "0xeFgH...5678",
      certificateType: "Degree Certificate",
      title: "Bachelor of Computer Science",
      description: "Completed 4-year computer science program with honors",
      requestDate: "2025-04-10",
      completedDate: "2025-04-12",
      status: "Approved"
    },
    {
      id: "REQ-005",
      student: "Olivia Martinez",
      walletAddress: "0xQrSt...7890",
      certificateType: "Workshop Completion",
      title: "Data Science Workshop",
      description: "Attended the data science workshop on April 8",
      requestDate: "2025-04-08",
      completedDate: "2025-04-09",
      status: "Rejected",
      reason: "Insufficient attendance hours"
    }
  ];

  // Filter requests based on search term
  const filteredPendingRequests = certificateRequests.filter(req =>
    req.student.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredCompletedRequests = completedRequests.filter(req =>
    req.student.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleViewDetails = (request: typeof certificateRequests[0]) => {
    setViewRequestDetails(request);
  };

  const handleApprove = (id: string) => {
    setIsProcessing(true);
    
    // Simulate processing
    setTimeout(() => {
      toast.success("Request approved", {
        description: "Certificate request has been approved. You can now issue the certificate."
      });
      setIsProcessing(false);
      setViewRequestDetails(null);
    }, 1500);
  };

  const handleReject = (id: string) => {
    setIsProcessing(true);
    
    // Simulate processing
    setTimeout(() => {
      toast.success("Request rejected", {
        description: "Certificate request has been rejected. The student will be notified."
      });
      setIsProcessing(false);
      setViewRequestDetails(null);
    }, 1500);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Certificate Requests</h1>
        <p className="text-muted-foreground mt-2">
          Review and manage student requests for certificate issuance
        </p>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by student name, request ID, or certificate title..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="pending" className="space-y-6">
        <TabsList>
          <TabsTrigger value="pending">Pending Requests</TabsTrigger>
          <TabsTrigger value="completed">Completed Requests</TabsTrigger>
        </TabsList>

        <TabsContent value="pending">
          <Card>
            <div className="divide-y divide-border">
              {filteredPendingRequests.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-muted-foreground">No pending requests found</p>
                </div>
              ) : (
                filteredPendingRequests.map((request) => (
                  <div key={request.id} className="p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="flex items-center">
                        <span className="font-medium">{request.title}</span>
                        <span className="ml-2 bg-amber-100 text-amber-800 text-xs px-2 py-0.5 rounded-full">
                          {request.status}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        <span>{request.student}</span> · <span>Request #{request.id}</span> · 
                        <span className="ml-1">{new Date(request.requestDate).toLocaleDateString()}</span>
                      </p>
                      <p className="text-sm mt-1 line-clamp-1">{request.description}</p>
                    </div>
                    <div className="flex items-center gap-2 mt-3 sm:mt-0">
                      <Button size="sm" variant="outline" onClick={() => handleViewDetails(request)}>
                        Details
                      </Button>
                      <Button size="sm" variant="default" onClick={() => handleApprove(request.id)}>
                        <Check className="h-4 w-4 mr-1" /> Approve
                      </Button>
                      <Button size="sm" variant="outline" className="text-destructive" onClick={() => handleReject(request.id)}>
                        <X className="h-4 w-4 mr-1" /> Reject
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="completed">
          <Card>
            <div className="divide-y divide-border">
              {filteredCompletedRequests.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-muted-foreground">No completed requests found</p>
                </div>
              ) : (
                filteredCompletedRequests.map((request) => (
                  <div key={request.id} className="p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="flex items-center">
                        <span className="font-medium">{request.title}</span>
                        <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${
                          request.status === "Approved" 
                            ? "bg-green-100 text-green-800" 
                            : "bg-red-100 text-red-800"
                        }`}>
                          {request.status}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        <span>{request.student}</span> · <span>Request #{request.id}</span> · 
                        <span className="ml-1">{new Date(request.completedDate).toLocaleDateString()}</span>
                      </p>
                      {request.status === "Rejected" && request.reason && (
                        <p className="text-sm text-red-500 mt-1">Reason: {request.reason}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-3 sm:mt-0">
                      <Button size="sm" variant="outline" onClick={() => handleViewDetails(request)}>
                        View Details
                      </Button>
                      {request.status === "Approved" && (
                        <Button size="sm" asChild>
                          <a href={`/institute/issue?student=${request.id}`}>
                            Issue Certificate
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Request Details Dialog */}
      <Dialog open={viewRequestDetails !== null} onOpenChange={(open) => !open && setViewRequestDetails(null)}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Certificate Request Details</DialogTitle>
            <DialogDescription>
              Review the details of the certificate request below
            </DialogDescription>
          </DialogHeader>
          
          {viewRequestDetails && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Request ID</h3>
                  <p>{viewRequestDetails.id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Request Date</h3>
                  <p>{new Date(viewRequestDetails.requestDate).toLocaleDateString()}</p>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">Student</h3>
                <p>{viewRequestDetails.student}</p>
                <p className="text-xs text-muted-foreground font-mono mt-0.5">{viewRequestDetails.walletAddress}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Certificate Type</h3>
                  <p>{viewRequestDetails.certificateType}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Title</h3>
                  <p>{viewRequestDetails.title}</p>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">Description</h3>
                <p className="text-sm">{viewRequestDetails.description}</p>
              </div>
              
              <div className="bg-muted/30 p-3 rounded-lg flex items-start mt-2">
                <Info className="h-5 w-5 text-muted-foreground mr-2 mt-0.5" />
                <p className="text-sm text-muted-foreground">
                  Approving this request will allow you to issue the certificate. The student will be notified once the request is processed.
                </p>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewRequestDetails(null)} disabled={isProcessing}>
              Cancel
            </Button>
            <Button 
              variant="outline" 
              className="text-destructive" 
              onClick={() => viewRequestDetails && handleReject(viewRequestDetails.id)}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing
                </>
              ) : (
                <>
                  <X className="h-4 w-4 mr-1" /> Reject
                </>
              )}
            </Button>
            <Button 
              onClick={() => viewRequestDetails && handleApprove(viewRequestDetails.id)}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing
                </>
              ) : (
                <>
                  <Check className="h-4 w-4 mr-1" /> Approve
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Requests;
