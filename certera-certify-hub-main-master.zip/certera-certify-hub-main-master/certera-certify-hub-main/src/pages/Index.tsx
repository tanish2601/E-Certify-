import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/layout/Navbar";
import { useWeb3 } from "@/context/Web3Context";

const Index = () => {
  const { isConnected } = useWeb3();

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.3,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
  };

  // Features list
  const features = [
    {
      title: "Blockchain Security",
      description: "All certificates are secured on the Ethereum blockchain with immutable records",
      icon: (
        <div className="w-12 h-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
        </div>
      ),
    },
    {
      title: "Encrypted Storage",
      description: "Files are encrypted and stored on IPFS for decentralized security",
      icon: (
        <div className="w-12 h-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="16" x="3" y="4" rx="2"></rect><path d="M7 8h.01"></path><path d="M11 8h.01"></path><path d="M15 8h.01"></path><path d="M7 12h.01"></path><path d="M11 12h.01"></path><path d="M15 12h.01"></path><path d="M7 16h.01"></path><path d="M11 16h.01"></path><path d="M15 16h.01"></path></svg>
        </div>
      ),
    },
    {
      title: "Multi-Signature Verification",
      description: "Certificates require both student and institute signatures",
      icon: (
        <div className="w-12 h-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 7h-9"></path><path d="M14 17H5"></path><circle cx="17" cy="17" r="3"></circle><circle cx="7" cy="7" r="3"></circle></svg>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <motion.section
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="relative pt-20 lg:pt-32 px-4 overflow-hidden"
      >
        <div className="container mx-auto">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="flex-1">
              <motion.h1
                variants={itemVariants}
                className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"
              >
                Secure Certificates on the Blockchain
              </motion.h1>

              <motion.p
                variants={itemVariants}
                className="text-lg text-muted-foreground mb-8 max-w-xl"
              >
                E-Certify is a decentralized platform that allows institutions to issue, verify, and manage academic and professional certificates with blockchain security and IPFS storage.
              </motion.p>

              <motion.div variants={itemVariants} className="flex flex-wrap gap-4">
                <Button size="lg" asChild>
                  <Link to={isConnected ? "/register" : "#"} onClick={!isConnected ? () => {} : undefined}>
                    {isConnected ? "Get Started" : "Connect Wallet"}
                  </Link>
                </Button>

                <Button size="lg" variant="outline" asChild>
                  <Link to="/features">Learn More</Link>
                </Button>
              </motion.div>
            </div>

            <motion.div
              variants={itemVariants}
              className="flex-1 relative"
            >
              <div className="relative w-full aspect-square max-w-md mx-auto">
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-primary/30 to-accent/30 blur-2xl" />
                <img
                  src="https://templates.images.credential.net/1565786962920108.png"
                  alt="Secure Certificate Platform"
                  className="relative z-10 rounded-2xl shadow-xl w-full h-full object-cover"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Features Section */}
      <section className="py-20 px-4" id="features">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Key Features</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our platform combines cutting-edge blockchain technology with user-friendly interfaces to revolutionize certificate management
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-card border border-border p-6 rounded-xl"
              >
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-medium mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 px-4 bg-muted/50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How It Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Follow these simple steps to secure and manage your certificates on the blockchain
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Connect Wallet", desc: "Connect with MetaMask to access the platform" },
              { step: "02", title: "Register", desc: "Register as a student or institute with verified credentials" },
              { step: "03", title: "Issue Certificate", desc: "Institutes upload and verify student certificates" },
              { step: "04", title: "Share Securely", desc: "Students can securely share certificates with time-limited access" },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="relative"
              >
                <div className="bg-card border border-border p-6 rounded-xl relative z-10 h-full">
                  <span className="text-4xl font-bold text-primary/20 mb-4 block">{item.step}</span>
                  <h3 className="text-xl font-medium mb-2">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </div>
                {index < 3 && (
                  <div className="hidden md:block absolute top-1/2 right-0 w-full h-0.5 bg-border z-0 transform translate-x-1/2">
                    <div className="absolute top-1/2 right-0 w-3 h-3 rounded-full bg-primary transform -translate-y-1/2"></div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-center justify-between gap-8">
              <div>
                <h2 className="text-3xl font-bold mb-4">Ready to secure your certificates?</h2>
                <p className="text-muted-foreground mb-6 md:mb-0 max-w-md">
                  Join our platform today and experience the future of secure, verifiable credentials on the blockchain.
                </p>
              </div>
              <Button size="lg" className="px-6" asChild>
                <Link to={isConnected ? "/register" : "#"} onClick={!isConnected ? () => {} : undefined}>
                  {isConnected ? "Get Started" : "Connect Wallet"}
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-border">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                E-Certify
              </span>
              <p className="text-sm text-muted-foreground mt-2">
                Securing certificates on the blockchain
              </p>
            </div>
            <div className="flex gap-8">
              <Link to="/about" className="text-sm text-muted-foreground hover:text-foreground">
                About
              </Link>
              <Link to="/features" className="text-sm text-muted-foreground hover:text-foreground">
                Features
              </Link>
              <Link to="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} E-Certify. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
