
import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { 
  Search,
  Filter,
  Download,
  Share2,
  ExternalLink,
  CheckCircle,
  Clock,
  Grid2X2,
  List 
} from "lucide-react";

interface Certificate {
  id: string;
  title: string;
  issuer: string;
  issued: string;
  category: string;
  hash: string;
  ipfsLink: string;
  thumbnailUrl: string;
}

const MyCertificates = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [activeTab, setActiveTab] = useState("all");
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [selectedCertificate, setSelectedCertificate] = useState<Certificate | null>(null);
  
  // Sample certificates data
  const certificates: Certificate[] = [
    {
      id: "cert-001",
      title: "Bachelor of Computer Science",
      issuer: "Tech University",
      issued: "2024-12-15",
      category: "Degree",
      hash: "0x1a2b3c4d5e6f",
      ipfsLink: "ipfs://bafkreih5bz7qj2t7cbgkrjujlsjse26toyywp2ve5n2jnvvtu7iucul6ci",
      thumbnailUrl: "/placeholder.svg"
    },
    {
      id: "cert-002",
      title: "Advanced Web Development",
      issuer: "CodeCamp Institute",
      issued: "2024-11-05",
      category: "Certificate",
      hash: "0xf6e5d4c3b2a1",
      ipfsLink: "ipfs://bafkreihfaizbpahgpt7yh7vpojtj3o6dasye3auu53wyjzwsbngfrawxde",
      thumbnailUrl: "/placeholder.svg"
    },
    {
      id: "cert-003",
      title: "Data Science Specialization",
      issuer: "Data Academy",
      issued: "2024-09-22",
      category: "Certificate",
      hash: "0x9f8e7d6c5b4a",
      ipfsLink: "ipfs://bafkreiew5r6bxmreygornbalt3u6wdddsbn75mmgkfhf6ewsxhvzz5n7oy",
      thumbnailUrl: "/placeholder.svg"
    },
    {
      id: "cert-004",
      title: "Machine Learning Workshop",
      issuer: "AI Labs",
      issued: "2024-08-10",
      category: "Workshop",
      hash: "0x4a5b6c7d8e9f",
      ipfsLink: "ipfs://bafkreigjmhgvzkqr7qp74ezzhkvqxuz4s2ysm47auzpuvyhbn5xxyz4kni",
      thumbnailUrl: "/placeholder.svg"
    }
  ];

  const filteredCertificates = certificates
    .filter(cert => cert.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                    cert.issuer.toLowerCase().includes(searchTerm.toLowerCase()))
    .filter(cert => activeTab === "all" || cert.category.toLowerCase() === activeTab.toLowerCase());

  const handleShareCertificate = (certificate: Certificate) => {
    setSelectedCertificate(certificate);
    setShareDialogOpen(true);
  };

  const handleShareSubmit = () => {
    // In a real app, this would create a shareable link
    console.log(`Creating share link for certificate: ${selectedCertificate?.id}`);
    setShareDialogOpen(false);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">My Certificates</h1>
        <p className="text-muted-foreground mt-2">
          View and manage your blockchain-verified certificates
        </p>
      </div>

      {/* Search and Filter Controls */}
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search certificates..."
            className="pl-9"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <div className="border rounded-md flex">
            <Button
              variant={viewMode === "grid" ? "secondary" : "ghost"}
              size="icon"
              onClick={() => setViewMode("grid")}
              className="rounded-none border-r"
            >
              <Grid2X2 className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "secondary" : "ghost"}
              size="icon"
              onClick={() => setViewMode("list")}
              className="rounded-none"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Certificate Category Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList>
          <TabsTrigger value="all">All Certificates</TabsTrigger>
          <TabsTrigger value="degree">Degrees</TabsTrigger>
          <TabsTrigger value="certificate">Certificates</TabsTrigger>
          <TabsTrigger value="workshop">Workshops</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Certificates Display */}
      {viewMode === "grid" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCertificates.length > 0 ? (
            filteredCertificates.map((cert) => (
              <motion.div
                key={cert.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="overflow-hidden hover:border-primary/50 transition-colors">
                  <div className="relative aspect-video bg-muted">
                    <img
                      src={cert.thumbnailUrl}
                      alt={cert.title}
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute bottom-2 right-2 bg-background/80 backdrop-blur-sm rounded-full px-2 py-1 text-xs font-medium flex items-center">
                      <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                      Verified
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold truncate">{cert.title}</h3>
                    <div className="flex items-center text-sm text-muted-foreground mt-1">
                      <span>{cert.issuer}</span>
                      <span className="mx-1">•</span>
                      <span>{new Date(cert.issued).toLocaleDateString()}</span>
                    </div>
                    <div className="mt-4 flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1" onClick={() => handleShareCertificate(cert)}>
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-muted-foreground">No certificates match your search criteria.</p>
            </div>
          )}
        </div>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-4">Certificate</th>
                  <th className="text-left p-4">Issuer</th>
                  <th className="text-left p-4">Issued Date</th>
                  <th className="text-left p-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filteredCertificates.length > 0 ? (
                  filteredCertificates.map((cert) => (
                    <tr key={cert.id} className="hover:bg-muted/30">
                      <td className="p-4">
                        <div className="font-medium">{cert.title}</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          Type: {cert.category}
                        </div>
                      </td>
                      <td className="p-4">{cert.issuer}</td>
                      <td className="p-4">{new Date(cert.issued).toLocaleDateString()}</td>
                      <td className="p-4">
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => handleShareCertificate(cert)}>
                            <Share2 className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" asChild>
                            <Link to={`/certificates/${cert.id}`}>
                              <ExternalLink className="h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="text-center p-8 text-muted-foreground">
                      No certificates match your search criteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Share Certificate Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Share Certificate</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Certificate</h3>
              <p className="text-sm">{selectedCertificate?.title}</p>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Share Options</h3>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" className="justify-start">
                  <Clock className="h-4 w-4 mr-2" />
                  24 Hours Access
                </Button>
                <Button variant="outline" className="justify-start">
                  <Clock className="h-4 w-4 mr-2" />
                  7 Days Access
                </Button>
                <Button variant="outline" className="justify-start">
                  <Clock className="h-4 w-4 mr-2" />
                  30 Days Access
                </Button>
                <Button variant="outline" className="justify-start">
                  <Clock className="h-4 w-4 mr-2" />
                  Custom Period
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Share With</h3>
              <Input placeholder="Email address (optional)" />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleShareSubmit}>
              Generate Link
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MyCertificates;
