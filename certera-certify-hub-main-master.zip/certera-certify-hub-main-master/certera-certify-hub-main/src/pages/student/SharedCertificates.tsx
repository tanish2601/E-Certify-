
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/sonner";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Share2, Copy, Clock, Eye, X } from "lucide-react";

const SharedCertificates = () => {
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [selectedShare, setSelectedShare] = useState<null | {
    id: string;
    certificateId: string;
    certificateTitle: string;
    accessType: string;
    shareTo: string;
    expiryDate: string;
    shareLink: string;
    views: number;
  }>(null);

  const sharedCertificates = [
    {
      id: "share-001",
      certificateId: "cert-001",
      certificateTitle: "Bachelor of Computer Science",
      accessType: "View Only",
      shareTo: "Example Corp HR",
      expiryDate: "2025-04-25",
      shareLink: "https://e-certify.example/share/abc123",
      views: 3,
    },
    {
      id: "share-002",
      certificateId: "cert-002",
      certificateTitle: "Advanced Web Development",
      accessType: "View & Download",
      shareTo: "Tech Startup Inc",
      expiryDate: "2025-04-30",
      shareLink: "https://e-certify.example/share/def456",
      views: 1,
    },
    {
      id: "share-003",
      certificateId: "cert-003",
      certificateTitle: "Data Science Specialization",
      accessType: "View Only",
      shareTo: "Data Analytics Co",
      expiryDate: "2025-05-10",
      shareLink: "https://e-certify.example/share/ghi789",
      views: 0,
    }
  ];

  const handleRevokeAccess = (id: string) => {
    toast.success("Access revoked", {
      description: "The shared certificate access has been revoked."
    });
  };

  const handleCopyLink = (link: string) => {
    navigator.clipboard.writeText(link);
    toast.success("Link copied to clipboard");
  };

  const handleExtendAccess = (share: typeof sharedCertificates[0]) => {
    setSelectedShare(share);
    setShareDialogOpen(true);
  };

  const handleExtendAccessSubmit = () => {
    // In a real app, this would extend the access period
    toast.success("Access period extended", {
      description: "The sharing period has been extended successfully."
    });
    setShareDialogOpen(false);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Shared Certificates</h1>
        <p className="text-muted-foreground mt-2">
          Manage certificates you've shared with others
        </p>
      </div>

      <Card className="mb-6">
        <div className="p-6 border-b border-border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-lg font-medium">Active Shares</h2>
            <p className="text-sm text-muted-foreground">
              {sharedCertificates.length} certificates are currently being shared
            </p>
          </div>
          
          <div>
            <Button>
              <Share2 className="mr-2 h-4 w-4" /> Share New Certificate
            </Button>
          </div>
        </div>
        
        <div className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Certificate</TableHead>
                <TableHead>Shared With</TableHead>
                <TableHead>Access Type</TableHead>
                <TableHead>Expiry Date</TableHead>
                <TableHead>Views</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sharedCertificates.map((share) => {
                const isExpiring = new Date(share.expiryDate).getTime() - new Date().getTime() < 3 * 24 * 60 * 60 * 1000; // 3 days
                const daysLeft = Math.ceil((new Date(share.expiryDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                
                return (
                  <TableRow key={share.id}>
                    <TableCell className="font-medium">{share.certificateTitle}</TableCell>
                    <TableCell>{share.shareTo}</TableCell>
                    <TableCell>{share.accessType}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className={isExpiring ? "text-amber-600" : ""}>{new Date(share.expiryDate).toLocaleDateString()}</span>
                        {isExpiring && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger>
                                <Clock className="h-4 w-4 ml-2 text-amber-600" />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Expires in {daysLeft} days</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{share.views}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => handleCopyLink(share.shareLink)}>
                          <Copy className="h-4 w-4" />
                          <span className="sr-only">Copy Link</span>
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Eye className="h-4 w-4" />
                          <span className="sr-only">View Access Logs</span>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleRevokeAccess(share.id)}>
                          <X className="h-4 w-4" />
                          <span className="sr-only">Revoke Access</span>
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleExtendAccess(share)}>
                          Extend
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}

              {sharedCertificates.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                    No shared certificates found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Access Log Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Recent Access Events</h2>
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Certificate</TableHead>
                <TableHead>Accessed By</TableHead>
                <TableHead>IP Address</TableHead>
                <TableHead>Timestamp</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                { 
                  id: "log-001", 
                  certificate: "Bachelor of Computer Science",
                  accessedBy: "Example Corp HR",
                  ipAddress: "192.168.1.100",
                  timestamp: "2025-04-22T14:32:00",
                  action: "View"
                },
                { 
                  id: "log-002", 
                  certificate: "Bachelor of Computer Science",
                  accessedBy: "Example Corp HR",
                  ipAddress: "192.168.1.100",
                  timestamp: "2025-04-21T10:15:00",
                  action: "View"
                },
                { 
                  id: "log-003", 
                  certificate: "Advanced Web Development",
                  accessedBy: "Tech Startup Inc",
                  ipAddress: "192.168.2.200",
                  timestamp: "2025-04-20T09:45:00",
                  action: "View"
                }
              ].map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="font-medium">{log.certificate}</TableCell>
                  <TableCell>{log.accessedBy}</TableCell>
                  <TableCell>{log.ipAddress}</TableCell>
                  <TableCell>{new Date(log.timestamp).toLocaleString()}</TableCell>
                  <TableCell>{log.action}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>

      {/* Extend Access Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Extend Access Period</DialogTitle>
            <DialogDescription>
              Select a new expiry date for the shared certificate
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Certificate</h3>
              <p className="text-sm">{selectedShare?.certificateTitle}</p>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Currently Shared With</h3>
              <p className="text-sm">{selectedShare?.shareTo}</p>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Current Expiry Date</h3>
              <p className="text-sm">{selectedShare && new Date(selectedShare.expiryDate).toLocaleDateString()}</p>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Extend Access By</h3>
              <div className="flex items-center space-x-2">
                <Button size="sm" className="flex-1">7 Days</Button>
                <Button size="sm" variant="outline" className="flex-1">30 Days</Button>
                <Button size="sm" variant="outline" className="flex-1">90 Days</Button>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleExtendAccessSubmit}>
              Extend Access
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SharedCertificates;
