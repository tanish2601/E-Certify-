
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useUserStore } from "@/store/userStore";
import { Link } from "react-router-dom";

const StudentDashboard = () => {
  const { profile } = useUserStore();
  const [stats] = useState({
    totalCertificates: 8,
    pendingRequests: 2,
    sharedCertificates: 3,
    pendingVerifications: 1
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Welcome, {profile?.name}</h1>
        <p className="text-muted-foreground mt-2">
          Manage your certificates and requests from your personalized dashboard
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="p-5 flex flex-col">
          <span className="text-sm text-muted-foreground">Total Certificates</span>
          <div className="flex items-baseline mt-2">
            <span className="text-3xl font-bold">{stats.totalCertificates}</span>
            <span className="text-sm text-muted-foreground ml-2">documents</span>
          </div>
          <Button variant="ghost" size="sm" className="mt-4" asChild>
            <Link to="/certificates">View All</Link>
          </Button>
        </Card>

        <Card className="p-5 flex flex-col">
          <span className="text-sm text-muted-foreground">Pending Requests</span>
          <div className="flex items-baseline mt-2">
            <span className="text-3xl font-bold">{stats.pendingRequests}</span>
            <span className="text-sm text-muted-foreground ml-2">requests</span>
          </div>
          <Button variant="ghost" size="sm" className="mt-4" asChild>
            <Link to="/request-certificate">View Requests</Link>
          </Button>
        </Card>

        <Card className="p-5 flex flex-col">
          <span className="text-sm text-muted-foreground">Shared Certificates</span>
          <div className="flex items-baseline mt-2">
            <span className="text-3xl font-bold">{stats.sharedCertificates}</span>
            <span className="text-sm text-muted-foreground ml-2">active links</span>
          </div>
          <Button variant="ghost" size="sm" className="mt-4" asChild>
            <Link to="/shared-certificates">View Shared</Link>
          </Button>
        </Card>

        <Card className="p-5 flex flex-col">
          <span className="text-sm text-muted-foreground">Pending Verifications</span>
          <div className="flex items-baseline mt-2">
            <span className="text-3xl font-bold">{stats.pendingVerifications}</span>
            <span className="text-sm text-muted-foreground ml-2">certificates</span>
          </div>
          <Button variant="ghost" size="sm" className="mt-4">
            View Pending
          </Button>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Recent Activity</h2>
          <Button variant="ghost" size="sm">View All</Button>
        </div>

        <div className="bg-card rounded-lg border border-border divide-y divide-border">
          {[
            {
              action: "Certificate Issued",
              description: "Bachelor of Computer Science has been issued by Tech University",
              time: "2 days ago"
            },
            {
              action: "Certificate Shared",
              description: "You shared Advanced Web Development Certificate with Example Corp",
              time: "1 week ago"
            },
            {
              action: "Certificate Request",
              description: "Your request for Machine Learning Certificate was approved",
              time: "2 weeks ago"
            }
          ].map((item, index) => (
            <div key={index} className="p-4 flex items-start">
              <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-4 shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path>
                  <path d="m9 12 2 2 4-4"></path>
                </svg>
              </div>
              <div className="flex-1">
                <p className="font-medium">{item.action}</p>
                <p className="text-sm text-muted-foreground">{item.description}</p>
                <p className="text-xs text-muted-foreground mt-1">{item.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
