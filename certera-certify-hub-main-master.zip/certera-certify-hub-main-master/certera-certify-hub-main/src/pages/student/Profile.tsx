
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { toast } from "@/components/ui/sonner";
import { useUserStore } from "@/store/userStore";
import { useWeb3 } from "@/context/Web3Context";

const StudentProfile = () => {
  const { profile, setProfile } = useUserStore();
  const { account } = useWeb3();

  const [formData, setFormData] = useState({
    name: profile?.name || "",
    email: profile?.email || "",
    phone: "+1 234 567 8900",
    bio: "Student at Tech University, specializing in Computer Science with a focus on blockchain technology and decentralized applications.",
    institution: "Tech University",
    studentId: "ST12345",
    graduationYear: "2025"
  });

  const [notifications, setNotifications] = useState({
    certificateIssued: true,
    requestUpdates: true,
    accessNotifications: true,
    marketingEmails: false
  });

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNotificationChange = (setting: keyof typeof notifications) => {
    setNotifications(prev => ({ ...prev, [setting]: !prev[setting] }));
  };

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Update profile in store
    if (profile) {
      setProfile({
        ...profile,
        name: formData.name,
        email: formData.email
      });
    }
    
    toast.success("Profile updated successfully");
  };

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Security settings updated successfully");
  };

  const handleNotificationsUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Notification preferences updated");
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Profile</h1>
        <p className="text-muted-foreground mt-2">
          Manage your personal information and account settings
        </p>
      </div>

      <Tabs defaultValue="personal" className="space-y-8">
        <TabsList className="grid w-full grid-cols-3 md:w-auto">
          <TabsTrigger value="personal">Personal Info</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        {/* Personal Information Tab */}
        <TabsContent value="personal">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="col-span-1 p-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-32 h-32 rounded-full bg-primary/10 text-primary flex items-center justify-center text-4xl mb-4">
                  {formData.name.charAt(0)}
                </div>
                <h2 className="text-xl font-semibold">{formData.name}</h2>
                <p className="text-muted-foreground">{formData.email}</p>
                <p className="text-xs mt-2 bg-primary/10 text-primary px-2 py-1 rounded-full">Student</p>
                
                <div className="mt-6 w-full">
                  <div className="text-sm space-y-3">
                    <div>
                      <p className="text-muted-foreground">Wallet Address</p>
                      <p className="font-mono text-xs truncate">{account}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Institution</p>
                      <p>{formData.institution}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Student ID</p>
                      <p>{formData.studentId}</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="col-span-1 md:col-span-2 p-6">
              <h2 className="text-xl font-semibold mb-6">Personal Information</h2>
              <form onSubmit={handleProfileUpdate} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input 
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleProfileChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleProfileChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input 
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleProfileChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="graduationYear">Expected Graduation Year</Label>
                    <Input 
                      id="graduationYear"
                      name="graduationYear"
                      value={formData.graduationYear}
                      onChange={handleProfileChange}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea 
                    id="bio"
                    name="bio"
                    rows={4}
                    value={formData.bio}
                    onChange={handleProfileChange}
                  />
                </div>
                
                <div className="flex justify-end">
                  <Button type="submit">
                    Update Profile
                  </Button>
                </div>
              </form>
            </Card>
          </div>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-6">Security Settings</h2>
            <form onSubmit={handlePasswordUpdate} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
                  <div className="flex items-center space-x-2">
                    <Switch id="2fa" checked />
                    <Label htmlFor="2fa">Enable two-factor authentication for additional security</Label>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Two-factor authentication is currently enabled via your Ethereum wallet.
                    All transactions require your wallet signature.
                  </p>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Recovery Options</h3>
                  <div className="space-y-2">
                    <Label htmlFor="recoveryEmail">Recovery Email</Label>
                    <Input 
                      id="recoveryEmail"
                      type="email"
                      value={profile?.email || ""}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Your recovery email is used to recover access to your account if you lose access to your wallet.
                  </p>
                </div>
              </div>
              
              <div className="pt-4 border-t border-border">
                <h3 className="text-lg font-medium mb-4">Access History</h3>
                <div className="space-y-4">
                  {[
                    { device: "Chrome / Windows 10", location: "San Francisco, USA", time: "Today, 14:32" },
                    { device: "MetaMask Mobile / Android", location: "San Francisco, USA", time: "Yesterday, 10:15" }
                  ].map((session, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-card border border-border rounded-lg">
                      <div>
                        <p className="font-medium">{session.device}</p>
                        <p className="text-sm text-muted-foreground">{session.location} - {session.time}</p>
                      </div>
                      <Button variant="outline" size="sm">Sign Out</Button>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button type="submit">
                  Update Security Settings
                </Button>
              </div>
            </form>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-6">Notification Preferences</h2>
            <form onSubmit={handleNotificationsUpdate} className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between py-3">
                  <div>
                    <h3 className="font-medium">Certificate Issued</h3>
                    <p className="text-sm text-muted-foreground">Receive notifications when a new certificate is issued to you</p>
                  </div>
                  <Switch 
                    checked={notifications.certificateIssued} 
                    onCheckedChange={() => handleNotificationChange('certificateIssued')}
                  />
                </div>
                
                <div className="flex items-center justify-between py-3 border-t border-border">
                  <div>
                    <h3 className="font-medium">Certificate Request Updates</h3>
                    <p className="text-sm text-muted-foreground">Notifications about your certificate requests status changes</p>
                  </div>
                  <Switch 
                    checked={notifications.requestUpdates} 
                    onCheckedChange={() => handleNotificationChange('requestUpdates')}
                  />
                </div>
                
                <div className="flex items-center justify-between py-3 border-t border-border">
                  <div>
                    <h3 className="font-medium">Shared Certificate Access</h3>
                    <p className="text-sm text-muted-foreground">Get notified when someone views your shared certificates</p>
                  </div>
                  <Switch 
                    checked={notifications.accessNotifications} 
                    onCheckedChange={() => handleNotificationChange('accessNotifications')}
                  />
                </div>
                
                <div className="flex items-center justify-between py-3 border-t border-border">
                  <div>
                    <h3 className="font-medium">Marketing Emails</h3>
                    <p className="text-sm text-muted-foreground">Receive updates about new features and platform improvements</p>
                  </div>
                  <Switch 
                    checked={notifications.marketingEmails} 
                    onCheckedChange={() => handleNotificationChange('marketingEmails')}
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t border-border">
                <h3 className="text-lg font-medium mb-4">Notification Channels</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="border border-border rounded-lg p-4 text-center">
                      <h4 className="font-medium mb-2">Email</h4>
                      <p className="text-sm text-muted-foreground mb-2">{profile?.email}</p>
                      <Button variant="outline" size="sm" className="w-full">Verify</Button>
                    </div>
                    
                    <div className="border border-border rounded-lg p-4 text-center">
                      <h4 className="font-medium mb-2">Browser</h4>
                      <p className="text-sm text-muted-foreground mb-2">Push notifications</p>
                      <Button variant="outline" size="sm" className="w-full">Enable</Button>
                    </div>
                    
                    <div className="border border-border rounded-lg p-4 text-center">
                      <h4 className="font-medium mb-2">MetaMask</h4>
                      <p className="text-sm text-muted-foreground mb-2">Wallet notifications</p>
                      <Button variant="outline" size="sm" className="w-full">Connected</Button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button type="submit">
                  Save Preferences
                </Button>
              </div>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default StudentProfile;
