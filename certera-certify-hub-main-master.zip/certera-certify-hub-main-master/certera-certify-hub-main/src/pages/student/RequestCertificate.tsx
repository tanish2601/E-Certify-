
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { toast } from "@/components/ui/sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const RequestCertificate = () => {
  const [formData, setFormData] = useState({
    certificateType: "",
    institute: "",
    course: "",
    completionDate: "",
    additionalInfo: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      toast.success("Certificate request submitted", {
        description: "Your request has been sent to the institute for review."
      });
      setFormData({
        certificateType: "",
        institute: "",
        course: "",
        completionDate: "",
        additionalInfo: ""
      });
      setIsSubmitting(false);
    }, 1500);
  };

  const pendingRequests = [
    {
      id: "req-001",
      type: "Course Certificate",
      institute: "Tech University",
      requestDate: "2025-04-10",
      status: "Pending"
    },
    {
      id: "req-002",
      type: "Skill Verification",
      institute: "CodeAcademy",
      requestDate: "2025-04-05",
      status: "Under Review"
    }
  ];

  const completedRequests = [
    {
      id: "req-003",
      type: "Degree Certificate",
      institute: "Tech University",
      requestDate: "2025-03-15",
      completedDate: "2025-03-20",
      status: "Approved"
    },
    {
      id: "req-004",
      type: "Workshop Completion",
      institute: "Data Institute",
      requestDate: "2025-02-28",
      completedDate: "2025-03-05",
      status: "Rejected"
    }
  ];

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Request Certificate</h1>
        <p className="text-muted-foreground mt-2">
          Submit requests for new certificates from your institutes
        </p>
      </div>

      <Tabs defaultValue="new-request" className="space-y-8">
        <TabsList>
          <TabsTrigger value="new-request">New Request</TabsTrigger>
          <TabsTrigger value="pending-requests">Pending Requests</TabsTrigger>
          <TabsTrigger value="completed-requests">Completed Requests</TabsTrigger>
        </TabsList>

        <TabsContent value="new-request">
          <Card className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="certificateType">Certificate Type</Label>
                  <Select 
                    onValueChange={(value) => handleSelectChange("certificateType", value)}
                    value={formData.certificateType}
                  >
                    <SelectTrigger id="certificateType">
                      <SelectValue placeholder="Select certificate type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="degree">Degree Certificate</SelectItem>
                      <SelectItem value="course">Course Completion</SelectItem>
                      <SelectItem value="workshop">Workshop Certificate</SelectItem>
                      <SelectItem value="skill">Skill Verification</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="institute">Institute Name</Label>
                  <Select
                    onValueChange={(value) => handleSelectChange("institute", value)}
                    value={formData.institute}
                  >
                    <SelectTrigger id="institute">
                      <SelectValue placeholder="Select an institute" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tech-university">Tech University</SelectItem>
                      <SelectItem value="code-academy">CodeAcademy</SelectItem>
                      <SelectItem value="data-institute">Data Institute</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="course">Course/Program Name</Label>
                  <Input 
                    id="course"
                    name="course"
                    placeholder="Enter course or program name"
                    value={formData.course}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="completionDate">Completion Date</Label>
                  <Input 
                    id="completionDate"
                    name="completionDate"
                    type="date"
                    value={formData.completionDate}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="additionalInfo">Additional Information</Label>
                <Textarea 
                  id="additionalInfo"
                  name="additionalInfo"
                  placeholder="Any additional details that might help verify your certificate request"
                  rows={4}
                  value={formData.additionalInfo}
                  onChange={handleChange}
                />
              </div>

              <div className="flex justify-end">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Submitting..." : "Submit Request"}
                </Button>
              </div>
            </form>
          </Card>
        </TabsContent>

        <TabsContent value="pending-requests">
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Request ID</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Institute</TableHead>
                  <TableHead>Request Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingRequests.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No pending requests found
                    </TableCell>
                  </TableRow>
                ) : (
                  pendingRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell className="font-medium">{request.id}</TableCell>
                      <TableCell>{request.type}</TableCell>
                      <TableCell>{request.institute}</TableCell>
                      <TableCell>{new Date(request.requestDate).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <span 
                          className={`px-2 py-1 rounded-full text-xs ${
                            request.status === "Pending" 
                              ? "bg-yellow-100 text-yellow-800" 
                              : "bg-blue-100 text-blue-800"
                          }`}
                        >
                          {request.status}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">Details</Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        <TabsContent value="completed-requests">
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Request ID</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Institute</TableHead>
                  <TableHead>Completed Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {completedRequests.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No completed requests found
                    </TableCell>
                  </TableRow>
                ) : (
                  completedRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell className="font-medium">{request.id}</TableCell>
                      <TableCell>{request.type}</TableCell>
                      <TableCell>{request.institute}</TableCell>
                      <TableCell>{new Date(request.completedDate).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <span 
                          className={`px-2 py-1 rounded-full text-xs ${
                            request.status === "Approved" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-red-100 text-red-800"
                          }`}
                        >
                          {request.status}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">Details</Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RequestCertificate;
