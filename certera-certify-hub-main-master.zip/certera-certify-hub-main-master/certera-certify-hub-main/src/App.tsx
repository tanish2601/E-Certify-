
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Web3Provider } from "@/context/Web3Context";
import { useUserStore } from "@/store/userStore";

// Layouts
import DashboardLayout from "@/components/layout/DashboardLayout";

// Public Pages
import Index from "@/pages/Index";
import NotFound from "@/pages/NotFound";
import Register from "@/pages/Register";
import About from "@/pages/About";
import Features from "@/pages/Features";
import Contact from "@/pages/Contact";

// Student Pages
import StudentDashboard from "@/pages/student/Dashboard";
import MyCertificates from "@/pages/student/MyCertificates";
import RequestCertificate from "@/pages/student/RequestCertificate";
import SharedCertificates from "@/pages/student/SharedCertificates";
import StudentProfile from "@/pages/student/Profile";

// Institute Pages
import InstituteDashboard from "@/pages/institute/Dashboard";
import Students from "@/pages/institute/Students";
import IssueCertificate from "@/pages/institute/IssueCertificate";
import Requests from "@/pages/institute/Requests";
import InstituteProfile from "@/pages/institute/Profile";

// Shared Certificate Viewer
import CertificateView from "@/pages/shared/CertificateView";

const queryClient = new QueryClient();

// Auth guard for protected routes
const ProtectedRoute = ({ children, requiredRole }: { children: React.ReactNode, requiredRole?: "student" | "institute" }) => {
  const { isAuthenticated, profile } = useUserStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  
  if (requiredRole && profile?.role !== requiredRole) {
    return <Navigate to={profile?.role === "student" ? "/dashboard" : "/institute/dashboard"} replace />;
  }
  
  return <>{children}</>;
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Web3Provider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Index />} />
              <Route path="/register" element={<Register />} />
              <Route path="/about" element={<About />} />
              <Route path="/features" element={<Features />} />
              <Route path="/contact" element={<Contact />} />
              
              {/* Student Routes */}
              <Route path="/dashboard" element={
                <ProtectedRoute requiredRole="student">
                  <DashboardLayout>
                    <StudentDashboard />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              <Route path="/certificates" element={
                <ProtectedRoute requiredRole="student">
                  <DashboardLayout>
                    <MyCertificates />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              <Route path="/request-certificate" element={
                <ProtectedRoute requiredRole="student">
                  <DashboardLayout>
                    <RequestCertificate />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              <Route path="/shared-certificates" element={
                <ProtectedRoute requiredRole="student">
                  <DashboardLayout>
                    <SharedCertificates />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              <Route path="/profile" element={
                <ProtectedRoute requiredRole="student">
                  <DashboardLayout>
                    <StudentProfile />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              
              {/* Institute Routes */}
              <Route path="/institute/dashboard" element={
                <ProtectedRoute requiredRole="institute">
                  <DashboardLayout>
                    <InstituteDashboard />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              <Route path="/institute/students" element={
                <ProtectedRoute requiredRole="institute">
                  <DashboardLayout>
                    <Students />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              <Route path="/institute/issue" element={
                <ProtectedRoute requiredRole="institute">
                  <DashboardLayout>
                    <IssueCertificate />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              <Route path="/institute/requests" element={
                <ProtectedRoute requiredRole="institute">
                  <DashboardLayout>
                    <Requests />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              <Route path="/institute/profile" element={
                <ProtectedRoute requiredRole="institute">
                  <DashboardLayout>
                    <InstituteProfile />
                  </DashboardLayout>
                </ProtectedRoute>
              } />
              
              {/* Shared Certificate View - Public with token */}
              <Route path="/shared/:id" element={<CertificateView />} />
              
              {/* 404 Route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </TooltipProvider>
        </Web3Provider>
      </BrowserRouter>
    </QueryClientProvider>
  );
};

export default App;
