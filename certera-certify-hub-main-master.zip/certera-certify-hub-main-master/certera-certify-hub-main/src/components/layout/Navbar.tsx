
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link, useLocation } from "react-router-dom";
import { useWeb3 } from "@/context/Web3Context";
import { useUserStore } from "@/store/userStore";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const { connectWallet, disconnectWallet, account, isConnected, isConnecting } = useWeb3();
  const { profile, isAuthenticated } = useUserStore();
  const location = useLocation();

  // Handle scroll effect for navbar
  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  // Define navigation links based on auth status and role
  const navLinks = isAuthenticated
    ? profile?.role === "student"
      ? [
          { name: "Dashboard", path: "/dashboard" },
          { name: "My Certificates", path: "/certificates" },
          { name: "Request Certificate", path: "/request-certificate" },
          { name: "Profile", path: "/profile" },
        ]
      : [
          { name: "Dashboard", path: "/institute/dashboard" },
          { name: "Students", path: "/institute/students" },
          { name: "Issue Certificate", path: "/institute/issue" },
          { name: "Requests", path: "/institute/requests" },
        ]
    : [
        { name: "Home", path: "/" },
        { name: "About", path: "/about" },
        { name: "Features", path: "/features" },
        { name: "Contact", path: "/contact" },
      ];

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-white/80 dark:bg-gray-900/80 backdrop-blur-md shadow-md"
          : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              E-Certify
            </span>
          </Link>

          {/* Navigation Links - Desktop */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-medium transition-colors ${
                  location.pathname === link.path
                    ? "text-primary dark:text-primary"
                    : "text-foreground/70 hover:text-foreground dark:text-foreground/70 dark:hover:text-foreground"
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Auth buttons */}
          <div className="flex items-center gap-4">
            {isConnected ? (
              <div className="flex items-center gap-2">
                <span className="hidden md:inline-flex px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium">
                  {formatAddress(account || "")}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={disconnectWallet}
                >
                  Disconnect
                </Button>
              </div>
            ) : (
              <Button
                onClick={connectWallet}
                disabled={isConnecting}
                className="relative overflow-hidden group"
              >
                <span className="relative z-10">
                  {isConnecting ? "Connecting..." : "Connect Wallet"}
                </span>
                <span className="absolute inset-0 bg-gradient-to-r from-primary/80 to-accent/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </Button>
            )}

            {!isAuthenticated && isConnected && (
              <Button
                variant="outline" 
                size="sm"
                asChild
              >
                <Link to="/register">Register</Link>
              </Button>
            )}
          </div>
        </div>
      </div>
    </motion.header>
  );
}
