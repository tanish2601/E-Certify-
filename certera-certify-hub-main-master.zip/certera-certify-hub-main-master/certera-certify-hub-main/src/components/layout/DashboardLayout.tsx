
import { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Sidebar } from "./Sidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import { useUserStore } from "@/store/userStore";
import { useNavigate } from "react-router-dom";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  const isMobile = useIsMobile();
  const { logout } = useUserStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="flex min-h-screen relative">
      {!isMobile && <Sidebar />}
      <div className="flex-1 flex flex-col">
        <Navbar />
        <main className="flex-1 p-4 pt-20 md:p-8 md:pt-24">
          {children}
        </main>
      </div>

      {/* Logout Button - Fixed at bottom right */}
      <Button
        onClick={handleLogout}
        className="fixed bottom-6 right-6 rounded-full w-12 h-12 shadow-lg flex items-center justify-center"
        size="icon"
        variant="default"
      >
        <LogOut className="h-5 w-5" />
        <span className="sr-only">Logout</span>
      </Button>
    </div>
  );
};

export default DashboardLayout;
