
import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useUserStore } from "@/store/userStore";
import {
  Home,
  GraduationCap,
  FileCheck,
  Share2,
  Settings,
  Building2,
  Users,
  FileText,
  Bell,
  Menu,
  X,
  LogOut
} from "lucide-react";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const { profile, logout } = useUserStore();
  const location = useLocation();
  const navigate = useNavigate();

  const isStudent = profile?.role === "student";

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const studentLinks = [
    {
      icon: Home,
      label: "Dashboard",
      href: "/dashboard",
    },
    {
      icon: GraduationCap,
      label: "My Certificates",
      href: "/certificates",
    },
    {
      icon: FileCheck,
      label: "Request Certificate",
      href: "/request-certificate",
    },
    {
      icon: Share2,
      label: "Shared Certificates",
      href: "/shared-certificates",
    },
    {
      icon: Settings,
      label: "Profile Settings",
      href: "/profile",
    },
  ];

  const instituteLinks = [
    {
      icon: Home,
      label: "Dashboard",
      href: "/institute/dashboard",
    },
    {
      icon: Users,
      label: "Students",
      href: "/institute/students",
    },
    {
      icon: FileText,
      label: "Issue Certificate",
      href: "/institute/issue",
    },
    {
      icon: Bell,
      label: "Requests",
      href: "/institute/requests",
    },
    {
      icon: Building2,
      label: "Institute Profile",
      href: "/institute/profile",
    },
  ];

  const links = isStudent ? studentLinks : instituteLinks;

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  return (
    <div
      className={cn(
        "bg-sidebar text-sidebar-foreground flex flex-col border-r border-sidebar-border transition-all duration-300",
        collapsed ? "w-16" : "w-64",
        className
      )}
    >
      <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
        {!collapsed && (
          <span className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            E-Certify
          </span>
        )}
        <button
          onClick={toggleCollapse}
          className="p-1 rounded-md hover:bg-sidebar-accent text-sidebar-foreground"
        >
          {collapsed ? <Menu size={20} /> : <X size={20} />}
        </button>
      </div>

      <div className="flex-1 py-6 overflow-y-auto">
        <nav className="px-2 space-y-1">
          {links.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className={cn(
                "flex items-center px-3 py-2 rounded-md transition-colors",
                location.pathname === link.href
                  ? "bg-primary text-primary-foreground"
                  : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}
            >
              <link.icon
                size={20}
                className={cn("flex-shrink-0", collapsed ? "mx-auto" : "mr-3")}
              />
              {!collapsed && <span>{link.label}</span>}
            </Link>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-sidebar-border">
        <div className={cn(
          "flex items-center",
          collapsed ? "justify-center" : "justify-start"
        )}>
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary">
            {profile?.name?.charAt(0) || "U"}
          </div>
          {!collapsed && (
            <div className="ml-3">
              <p className="text-sm font-medium">{profile?.name || "User"}</p>
              <p className="text-xs text-sidebar-foreground/70">{isStudent ? "Student" : "Institute"}</p>
            </div>
          )}
        </div>
      </div>

      {/* Logout Button */}
      <div className="mt-auto p-4 border-t border-sidebar-border">
        <button
          onClick={handleLogout}
          className={cn(
            "w-full flex items-center p-2 rounded-md text-sidebar-foreground hover:bg-sidebar-accent transition-colors",
            collapsed ? "justify-center" : "justify-between"
          )}
        >
          {!collapsed && <span className="text-sm font-medium">Logout</span>}
          <LogOut className={cn("w-5 h-5", collapsed ? "" : "ml-2")} />
        </button>
      </div>
    </div>
  );
}
