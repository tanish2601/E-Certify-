
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type UserRole = 'student' | 'institute' | null;

interface UserProfile {
  address: string;
  role: UserRole;
  name?: string;
  email?: string;
  isVerified: boolean;
}

interface UserState {
  profile: UserProfile | null;
  isAuthenticated: boolean;
  currentOTP: string | null;
  setProfile: (profile: UserProfile | null) => void;
  setRole: (role: UserRole) => void;
  setAuthenticated: (isAuthenticated: boolean) => void;
  setCurrentOTP: (otp: string | null) => void;
  logout: () => void;
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      profile: null,
      isAuthenticated: false,
      currentOTP: null,
      setProfile: (profile) => set({ profile }),
      setRole: (role) => 
        set((state) => ({
          profile: state.profile ? { ...state.profile, role } : null
        })),
      setAuthenticated: (isAuthenticated) => set({ isAuthenticated }),
      setCurrentOTP: (otp) => set({ currentOTP: otp }),
      logout: () => set({
        profile: null,
        isAuthenticated: false,
        currentOTP: null
      })
    }),
    {
      name: 'user-storage',
      partialize: (state) => ({
        profile: state.profile,
        isAuthenticated: state.isAuthenticated
      })
    }
  )
);
