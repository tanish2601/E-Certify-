
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Certificate {
  id: string;
  name: string;
  issuedTo: string;
  issuedBy: string;
  issueDate: string;
  expiryDate?: string;
  category: string;
  ipfsCid: string;
  encryptionKey: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  thumbnailUrl?: string;
  isVerified: boolean;
  verificationDate?: string;
  blockchainTxHash?: string;
  sharingLink?: string;
  sharingExpiry?: string;
}

interface CertificateState {
  certificates: Certificate[];
  pendingCertificates: Certificate[];
  sharedCertificates: Certificate[];
  activeCertificate: Certificate | null;
  addCertificate: (cert: Certificate) => void;
  updateCertificate: (id: string, updates: Partial<Certificate>) => void;
  removeCertificate: (id: string) => void;
  setActiveCertificate: (cert: Certificate | null) => void;
  addPendingCertificate: (cert: Certificate) => void;
  approvePendingCertificate: (id: string) => void;
  rejectPendingCertificate: (id: string) => void;
  createSharingLink: (id: string, expiryHours: number) => void;
  revokeSharingLink: (id: string) => void;
}

export const useCertificateStore = create<CertificateState>()(
  persist(
    (set) => ({
      certificates: [],
      pendingCertificates: [],
      sharedCertificates: [],
      activeCertificate: null,
      
      addCertificate: (cert) => set((state) => ({ 
        certificates: [...state.certificates, cert] 
      })),
      
      updateCertificate: (id, updates) => set((state) => ({
        certificates: state.certificates.map(cert => 
          cert.id === id ? { ...cert, ...updates } : cert
        )
      })),
      
      removeCertificate: (id) => set((state) => ({
        certificates: state.certificates.filter(cert => cert.id !== id)
      })),
      
      setActiveCertificate: (cert) => set({ activeCertificate: cert }),
      
      addPendingCertificate: (cert) => set((state) => ({
        pendingCertificates: [...state.pendingCertificates, cert]
      })),
      
      approvePendingCertificate: (id) => set((state) => {
        const approved = state.pendingCertificates.find(cert => cert.id === id);
        if (!approved) return state;
        
        return {
          pendingCertificates: state.pendingCertificates.filter(cert => cert.id !== id),
          certificates: [...state.certificates, { ...approved, isVerified: true }]
        };
      }),
      
      rejectPendingCertificate: (id) => set((state) => ({
        pendingCertificates: state.pendingCertificates.filter(cert => cert.id !== id)
      })),
      
      createSharingLink: (id, expiryHours) => set((state) => {
        const expiryDate = new Date();
        expiryDate.setHours(expiryDate.getHours() + expiryHours);
        
        return {
          certificates: state.certificates.map(cert => {
            if (cert.id === id) {
              const sharingLink = `${window.location.origin}/shared/${id}?token=${btoa(
                `${id}:${expiryDate.getTime()}`
              )}`;
              
              return {
                ...cert,
                sharingLink,
                sharingExpiry: expiryDate.toISOString()
              };
            }
            return cert;
          })
        };
      }),
      
      revokeSharingLink: (id) => set((state) => ({
        certificates: state.certificates.map(cert => {
          if (cert.id === id) {
            const { sharingLink, sharingExpiry, ...rest } = cert;
            return rest;
          }
          return cert;
        })
      }))
    }),
    {
      name: 'certificate-storage',
      partialize: (state) => ({
        certificates: state.certificates,
        pendingCertificates: state.pendingCertificates
      })
    }
  )
);
