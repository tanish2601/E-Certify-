
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { ethers } from "ethers";

interface Web3ContextType {
  provider: ethers.providers.Web3Provider | null;
  signer: ethers.Signer | null;
  account: string | null;
  chainId: number | null;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
}

const defaultContext: Web3ContextType = {
  provider: null,
  signer: null,
  account: null,
  chainId: null,
  connectWallet: async () => {},
  disconnectWallet: () => {},
  isConnected: false,
  isConnecting: false,
  error: null,
};

const Web3Context = createContext<Web3ContextType>(defaultContext);

export const useWeb3 = () => useContext(Web3Context);

export const Web3Provider = ({ children }: { children: ReactNode }) => {
  const [provider, setProvider] = useState<ethers.providers.Web3Provider | null>(null);
  const [signer, setSigner] = useState<ethers.Signer | null>(null);
  const [account, setAccount] = useState<string | null>(null);
  const [chainId, setChainId] = useState<number | null>(null);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Check if MetaMask is installed
  const checkIfWalletIsInstalled = () => {
    const { ethereum } = window as any;
    if (!ethereum) {
      setError("MetaMask is not installed. Please install MetaMask.");
      return false;
    }
    return true;
  };

  // Connect to the wallet
  const connectWallet = async () => {
    try {
      setIsConnecting(true);
      setError(null);

      if (!checkIfWalletIsInstalled()) {
        setIsConnecting(false);
        return;
      }

      const { ethereum } = window as any;
      const ethProvider = new ethers.providers.Web3Provider(ethereum, "any");
      
      // Request account access
      const accounts = await ethereum.request({ method: "eth_requestAccounts" });
      const account = accounts[0];
      
      // Get the network
      const network = await ethProvider.getNetwork();
      
      // Get signer
      const ethSigner = ethProvider.getSigner();

      setProvider(ethProvider);
      setSigner(ethSigner);
      setAccount(account);
      setChainId(network.chainId);
      setIsConnected(true);
      
      // Store connection state
      localStorage.setItem("isWalletConnected", "true");
    } catch (error: any) {
      console.error("Error connecting to MetaMask", error);
      setError(error.message || "Failed to connect to wallet");
    } finally {
      setIsConnecting(false);
    }
  };

  // Disconnect from the wallet
  const disconnectWallet = () => {
    setProvider(null);
    setSigner(null);
    setAccount(null);
    setChainId(null);
    setIsConnected(false);
    localStorage.removeItem("isWalletConnected");
  };

  // Reconnect if previously connected
  useEffect(() => {
    const checkConnection = async () => {
      if (localStorage.getItem("isWalletConnected") === "true") {
        await connectWallet();
      }
    };
    
    checkConnection();
  }, []);

  // Setup event listeners for wallet changes
  useEffect(() => {
    const { ethereum } = window as any;
    
    if (ethereum) {
      // Handle account changes
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length === 0) {
          disconnectWallet();
        } else if (accounts[0] !== account) {
          setAccount(accounts[0]);
        }
      };

      // Handle chain/network changes
      const handleChainChanged = (chainId: string) => {
        setChainId(parseInt(chainId, 16));
        // Force page refresh on chain change as recommended by MetaMask
        window.location.reload();
      };

      // Handle disconnect
      const handleDisconnect = () => {
        disconnectWallet();
      };

      // Subscribe to events
      ethereum.on("accountsChanged", handleAccountsChanged);
      ethereum.on("chainChanged", handleChainChanged);
      ethereum.on("disconnect", handleDisconnect);

      // Cleanup
      return () => {
        ethereum.removeListener("accountsChanged", handleAccountsChanged);
        ethereum.removeListener("chainChanged", handleChainChanged);
        ethereum.removeListener("disconnect", handleDisconnect);
      };
    }
  }, [account]);

  const value = {
    provider,
    signer,
    account,
    chainId,
    connectWallet,
    disconnectWallet,
    isConnected,
    isConnecting,
    error,
  };

  return <Web3Context.Provider value={value}>{children}</Web3Context.Provider>;
};
